<?php
header('Content-Type: application/json');
require_once 'config.php';

try {
    // Fetch only future events from newevent table
    $sql = "SELECT * FROM newevent WHERE event_date >= CURDATE() ORDER BY event_date ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $events = $stmt->fetchAll();
    
    echo json_encode(['success' => true, 'events' => $events]);
    
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
