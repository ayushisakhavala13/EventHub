<?php
header('Content-Type: application/json');
$conn = new mysqli('localhost', 'root', '', 'event');

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => $conn->connect_error]);
    exit;
}

// Error reporting for queries
function getCount($conn, $sql) {
    $result = $conn->query($sql);
    if (!$result) {
        return ['error' => $conn->error];
    }
    $row = $result->fetch_assoc();
    return (int)$row['cnt'];
}

$totalEvents = getCount($conn, "SELECT COUNT(*) as cnt FROM newevent");
$totalRegistrations = getCount($conn, "SELECT COUNT(*) as cnt FROM registrations");
$confirmedRegistrations = getCount($conn, "SELECT COUNT(*) as cnt FROM registrations WHERE status='confirmed'");
$pendingRegistrations = getCount($conn, "SELECT COUNT(*) as cnt FROM registrations WHERE status='pending'");
$activeEvents = getCount($conn, "SELECT COUNT(*) as cnt FROM newevent WHERE status='active'");

// This month's events
$thisMonthEvents = getCount(
    $conn,
    "SELECT COUNT(*) as cnt FROM newevent WHERE MONTH(event_date) = MONTH(CURDATE()) AND YEAR(event_date) = YEAR(CURDATE())"
);

echo json_encode([
    'success' => true,
    'total_events' => $totalEvents,
    'total_registrations' => $totalRegistrations,
    'confirmed_registrations' => $confirmedRegistrations,
    'pending_registrations' => $pendingRegistrations,
    'active_events' => $activeEvents,
    'this_month' => $thisMonthEvents
]);
$conn->close();