<?php
header('Content-Type: application/json');
$conn = new mysqli("localhost", "root", "", "event");
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}

$email = isset($_GET['email']) ? $conn->real_escape_string($_GET['email']) : '';

if ($email) {
    $sql = "SELECT r.*, e.event_name as actual_event_name 
            FROM registrations r 
            LEFT JOIN newevent e ON r.event_name = e.event_name 
            WHERE r.email='$email'";
} else {
    $sql = "SELECT r.*, e.event_name as actual_event_name 
            FROM registrations r 
            LEFT JOIN newevent e ON r.event_name = e.event_name 
            ORDER BY r.registration_date DESC";
}

$result = $conn->query($sql);
$registrations = [];
while ($row = $result->fetch_assoc()) {
    // Use actual event name if available, otherwise use the stored event name
    $row['event_name'] = $row['actual_event_name'] ?: $row['event_name'];
    unset($row['actual_event_name']); // Remove the temporary field
    $registrations[] = $row;
}
echo json_encode(['success' => true, 'registrations' => $registrations]);
$conn->close();
?>

