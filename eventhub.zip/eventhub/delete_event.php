<?php
header('Content-Type: application/json'); // JSON ki jagah plain text temporarily
error_reporting(E_ALL);
ini_set('display_errors', 1);

// --- Database connection yahin likho ---
$servername = "localhost";
$username = "root";
$password = ""; // XAMPP default password blank hota hai
$dbname = "event"; // Apne database ka naam yahan likho

$conn = new mysqli($servername, $username, $password, $dbname);

// Connection check
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit;
}
// ---------------------------------------

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id'] ?? 0);
    if ($id > 0) {
        $stmt = $conn->prepare("DELETE FROM newevent WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to delete event']);
        }
        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid event ID']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
}
$conn->close();
?>