<?php
header('Content-Type: application/json');
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Only POST method allowed']);
    exit;
}

$registrationId = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$newStatus = isset($_POST['status']) ? $_POST['status'] : '';
$paymentMethod = isset($_POST['payment_method']) ? $_POST['payment_method'] : null;

if ($registrationId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid registration ID']);
    exit;
}

if (!in_array($newStatus, ['pending', 'paid', 'confirmed', 'cancelled'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid status. Must be pending, paid, confirmed, or cancelled']);
    exit;
}

try {
    // Update the registration status and payment method
    if ($paymentMethod && $newStatus === 'paid') {
        $sql = "UPDATE registrations SET status = ?, payment_method = ? WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute([$newStatus, $paymentMethod, $registrationId]);
    } else {
        $sql = "UPDATE registrations SET status = ? WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute([$newStatus, $registrationId]);
    }
    
    if ($result) {
        echo json_encode([
            'success' => true, 
            'message' => 'Registration status updated successfully',
            'registration_id' => $registrationId,
            'new_status' => $newStatus,
            'payment_method' => $paymentMethod
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update registration status']);
    }
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
