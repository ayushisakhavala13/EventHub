<?php
require_once 'config.php';

echo "<h2>🔐 EventHub Login System Test</h2>";

try {
    // Check if login table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'login'");
    if ($stmt->rowCount() == 0) {
        echo "<p style='color: red;'>❌ Login table does not exist. Please run <a href='create_login_table.php'>create_login_table.php</a> first.</p>";
        exit;
    }
    
    echo "<div style='background-color: #e8f5e8; padding: 15px; border-left: 4px solid #14b8a6; margin: 20px 0;'>";
    echo "<h3 style='margin-top: 0; color: #14b8a6;'>🧪 How the Login System Works:</h3>";
    echo "<ol>";
    echo "<li><strong>First Time Login:</strong> When a user enters email and password for the first time, a new account is created</li>";
    echo "<li><strong>Password Verification:</strong> When the same user logs in again, their password is verified against the stored hash</li>";
    echo "<li><strong>Security:</strong> Passwords are never stored in plain text - they are hashed using PHP's secure password_hash() function</li>";
    echo "<li><strong>Login Tracking:</strong> Each successful login updates the 'last_login' timestamp</li>";
    echo "</ol>";
    echo "</div>";
    
    // Get all login records
    $stmt = $pdo->query("SELECT id, email, created_at, last_login, is_active FROM login ORDER BY created_at DESC");
    $records = $stmt->fetchAll();
    
    if (empty($records)) {
        echo "<p style='color: orange;'>⚠️ No login records found yet. Try logging in through <a href='change.php'>change.php</a> first.</p>";
    } else {
        echo "<h3>📊 Current Login Records:</h3>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%; margin: 10px 0; font-family: Arial, sans-serif;'>";
        echo "<tr style='background-color: #14b8a6; color: white;'>";
        echo "<th style='padding: 10px; text-align: left;'>ID</th>";
        echo "<th style='padding: 10px; text-align: left;'>Email Address</th>";
        echo "<th style='padding: 10px; text-align: left;'>Account Created</th>";
        echo "<th style='padding: 10px; text-align: left;'>Last Login</th>";
        echo "<th style='padding: 10px; text-align: left;'>Status</th>";
        echo "</tr>";
        
        $rowColor = true;
        foreach ($records as $record) {
            $bgColor = $rowColor ? '#f9f9f9' : '#ffffff';
            $lastLogin = $record['last_login'] ? date('Y-m-d H:i:s', strtotime($record['last_login'])) : 'Never';
            echo "<tr style='background-color: $bgColor;'>";
            echo "<td style='padding: 8px; border: 1px solid #ddd;'>{$record['id']}</td>";
            echo "<td style='padding: 8px; border: 1px solid #ddd;'>{$record['email']}</td>";
            echo "<td style='padding: 8px; border: 1px solid #ddd;'>{$record['created_at']}</td>";
            echo "<td style='padding: 8px; border: 1px solid #ddd;'>$lastLogin</td>";
            echo "<td style='padding: 8px; border: 1px solid #ddd;'>" . ($record['is_active'] ? '✅ Active' : '❌ Inactive') . "</td>";
            echo "</tr>";
            $rowColor = !$rowColor;
        }
        
        echo "</table>";
        
        echo "<div style='margin-top: 20px; padding: 15px; background-color: #fff3cd; border-left: 4px solid #ffc107;'>";
        echo "<h3 style='margin-top: 0; color: #856404;'>🔍 Test Instructions:</h3>";
        echo "<ol>";
        echo "<li>Go to <a href='change.php' target='_blank'>change.php</a> and login with any email/password</li>";
        echo "<li>You'll see 'Account created successfully!' message</li>";
        echo "<li>Logout and login again with the SAME email/password</li>";
        echo "<li>You'll see 'Login successful! Welcome back.' message</li>";
        echo "<li>Try logging in with the SAME email but DIFFERENT password</li>";
        echo "<li>You'll see 'Incorrect password. Please try again.' error</li>";
        echo "</ol>";
        echo "</div>";
    }
    
    echo "<div style='margin-top: 20px;'>";
    echo "<a href='change.php' style='background-color: #14b8a6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-right: 10px;'>🔑 Test Login</a>";
    echo "<a href='view_login_data.php' style='background-color: #6b7280; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-right: 10px;'>📊 View Data</a>";
    echo "<a href='create_login_table.php' style='background-color: #dc3545; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>⚙️ Setup</a>";
    echo "</div>";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>❌ Database error: " . $e->getMessage() . "</p>";
}
?>
