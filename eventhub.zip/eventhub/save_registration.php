<?php
header('Content-Type: application/json');
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

try {
    // Get form data
    $event_name = $_POST['event_name'] ?? '';
    $registration_type = $_POST['registration_type'] ?? '';
    $first_name = $_POST['first_name'] ?? '';
    $last_name = $_POST['last_name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $company = $_POST['company'] ?? '';
    $job_title = $_POST['job_title'] ?? '';
    $dietary_restrictions = $_POST['dietary_restrictions'] ?? '';
    $amount_paid = $_POST['amount_paid'] ?? 0;
    
    // Validate required fields
    if (empty($event_name) || empty($registration_type) || empty($first_name) || 
        empty($last_name) || empty($email) || empty($phone)) {
        echo json_encode(['success' => false, 'message' => 'All required fields must be filled']);
        exit;
    }
    
    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Please enter a valid email address']);
        exit;
    }
    
    // Check if user is already registered for this event
    $checkSql = "SELECT id FROM registrations WHERE email = :email AND event_name = :event_name";
    $checkStmt = $pdo->prepare($checkSql);
    $checkStmt->bindParam(':email', $email);
    $checkStmt->bindParam(':event_name', $event_name);
    $checkStmt->execute();
    
    if ($checkStmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'You are already registered for this event']);
        exit;
    }
    
    // Insert registration into database
    $sql = "INSERT INTO registrations (event_name, registration_type, first_name, last_name, email, phone, company, job_title, dietary_restrictions, amount_paid) 
            VALUES (:event_name, :registration_type, :first_name, :last_name, :email, :phone, :company, :job_title, :dietary_restrictions, :amount_paid)";
    
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':event_name', $event_name);
    $stmt->bindParam(':registration_type', $registration_type);
    $stmt->bindParam(':first_name', $first_name);
    $stmt->bindParam(':last_name', $last_name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':company', $company);
    $stmt->bindParam(':job_title', $job_title);
    $stmt->bindParam(':dietary_restrictions', $dietary_restrictions);
    $stmt->bindParam(':amount_paid', $amount_paid, PDO::PARAM_STR);
    
    if ($stmt->execute()) {
        $registration_id = $pdo->lastInsertId();
        echo json_encode([
            'success' => true, 
            'message' => 'Registration completed successfully!', 
            'registration_id' => $registration_id,
            'event_name' => $event_name
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to save registration']);
    }
    
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
