<?php
require_once 'config.php';

echo "<h2>📊 EventHub Login Data</h2>";

try {
    // Check if login table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'login'");
    if ($stmt->rowCount() == 0) {
        echo "<p style='color: red;'>❌ Login table does not exist. Please run <a href='create_login_table.php'>create_login_table.php</a> first.</p>";
        exit;
    }
    
    // Get all login records
    $stmt = $pdo->query("SELECT id, email, created_at, last_login, is_active FROM login ORDER BY created_at DESC");
    $records = $stmt->fetchAll();
    
    if (empty($records)) {
        echo "<p style='color: orange;'>⚠️ No login records found yet. Try logging in through <a href='change.php'>change.php</a> first.</p>";
    } else {
        echo "<p><strong>📈 Total login records: " . count($records) . "</strong></p>";
        
        echo "<table border='1' style='border-collapse: collapse; width: 100%; margin: 10px 0; font-family: Arial, sans-serif;'>";
        echo "<tr style='background-color: #14b8a6; color: white;'>";
        echo "<th style='padding: 10px; text-align: left;'>ID</th>";
        echo "<th style='padding: 10px; text-align: left;'>Email Address</th>";
        echo "<th style='padding: 10px; text-align: left;'>Created At</th>";
        echo "<th style='padding: 10px; text-align: left;'>Last Login</th>";
        echo "<th style='padding: 10px; text-align: left;'>Status</th>";
        echo "</tr>";
        
        $rowColor = true;
        foreach ($records as $record) {
            $bgColor = $rowColor ? '#f9f9f9' : '#ffffff';
            echo "<tr style='background-color: $bgColor;'>";
            echo "<td style='padding: 8px; border: 1px solid #ddd;'>{$record['id']}</td>";
            echo "<td style='padding: 8px; border: 1px solid #ddd;'>{$record['email']}</td>";
            echo "<td style='padding: 8px; border: 1px solid #ddd;'>{$record['created_at']}</td>";
            echo "<td style='padding: 8px; border: 1px solid #ddd;'>" . ($record['last_login'] ?: 'Never') . "</td>";
            echo "<td style='padding: 8px; border: 1px solid #ddd;'>" . ($record['is_active'] ? '✅ Active' : '❌ Inactive') . "</td>";
            echo "</tr>";
            $rowColor = !$rowColor;
        }
        
        echo "</table>";
        
        echo "<div style='margin-top: 20px; padding: 15px; background-color: #e8f5e8; border-left: 4px solid #14b8a6;'>";
        echo "<h3 style='margin-top: 0; color: #14b8a6;'>🔒 Security Information:</h3>";
        echo "<ul>";
        echo "<li>✅ Passwords are securely hashed using PHP's password_hash() function</li>";
        echo "<li>✅ Email addresses are unique in the database</li>";
        echo "<li>✅ All data is protected against SQL injection</li>";
        echo "<li>✅ Login timestamps are automatically tracked</li>";
        echo "</ul>";
        echo "</div>";
    }
    
    echo "<div style='margin-top: 20px;'>";
    echo "<a href='change.php' style='background-color: #14b8a6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-right: 10px;'>← Back to Login</a>";
    echo "<a href='create_login_table.php' style='background-color: #6b7280; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Setup Database</a>";
    echo "</div>";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>❌ Database error: " . $e->getMessage() . "</p>";
}
?>
