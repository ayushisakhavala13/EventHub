<?php
require_once 'config.php';

try {
    // Create login table in the event database
    $sql = "CREATE TABLE IF NOT EXISTS login (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_login TIMESTAMP NULL,
        is_active BOOLEAN DEFAULT TRUE
    )";
    
    $pdo->exec($sql);
    echo "✅ Login table created successfully in 'event' database!<br>";
    
    // Show table structure
    $stmt = $pdo->query("DESCRIBE login");
    $columns = $stmt->fetchAll();
    echo "<h3>Login Table Structure:</h3>";
    echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
    echo "<tr style='background-color: #f0f0f0;'><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    foreach ($columns as $column) {
        echo "<tr>";
        echo "<td style='padding: 5px;'>{$column['Field']}</td>";
        echo "<td style='padding: 5px;'>{$column['Type']}</td>";
        echo "<td style='padding: 5px;'>{$column['Null']}</td>";
        echo "<td style='padding: 5px;'>{$column['Key']}</td>";
        echo "<td style='padding: 5px;'>{$column['Default']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<br><strong>✅ Setup Complete! Now you can use the login form.</strong>";
    
} catch(PDOException $e) {
    echo "❌ Error creating login table: " . $e->getMessage();
}
?>
