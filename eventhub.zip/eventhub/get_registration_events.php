
<?php
header('Content-Type: application/json');

// Database connection details
$conn = new mysqli("localhost", "root", "", "event"); // <-- yahan apna database name dalein

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}

$sql = "SELECT DISTINCT event FROM registrations";
$result = $conn->query($sql);

if (!$result) {
    echo json_encode(['success' => false, 'message' => 'Query failed: ' . $conn->error]);
    exit;
}

$events = [];
while ($row = $result->fetch_assoc()) {
    $events[] = $row['event'];
}

echo json_encode(['success' => true, 'events' => $events]);
$conn->close();
?>