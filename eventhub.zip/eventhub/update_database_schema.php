<?php
require_once 'config.php';

try {
    // Update the registrations table to include 'paid' status
    $sql = "ALTER TABLE registrations MODIFY COLUMN status ENUM('pending', 'paid', 'confirmed', 'cancelled') DEFAULT 'pending'";
    
    $pdo->exec($sql);
    echo "Database schema updated successfully! Added 'paid' status to registrations table.<br>";
    
    // Add payment_method column if it doesn't exist
    $sql2 = "ALTER TABLE registrations ADD COLUMN payment_method VARCHAR(50) DEFAULT NULL";
    
    try {
        $pdo->exec($sql2);
        echo "Added payment_method column successfully!<br>";
    } catch(PDOException $e) {
        if ($e->getCode() == 1060) {
            echo "payment_method column already exists.<br>";
        } else {
            throw $e;
        }
    }
    
    echo "Database update completed!";
    
} catch(PDOException $e) {
    echo "Error updating database: " . $e->getMessage();
}
?>
