<?php
// filepath: c:\xampp\htdocs\eve\get_active_events_count.php
header('Content-Type: application/json');
$conn = new mysqli('localhost', 'root', '', 'event'); // 'eve' ko apne DB naam se badle agar alag ho

if ($conn->connect_error) {
    echo json_encode(['success' => false]);
    exit;
}

$sql = "SELECT COUNT(*) as cnt FROM newevent WHERE status='active'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

echo json_encode(['success' => true, 'count' => (int)$row['cnt']]);
$conn->close();