<?php
require_once 'config.php';

// Set content type to JSON for responses
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

try {
    // Get form data
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    // Validate input
    if (empty($email) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Email and password are required']);
        exit;
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Invalid email format']);
        exit;
    }
    
    // Hash the password for security
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Check if user already exists
    $checkStmt = $pdo->prepare("SELECT id, password FROM login WHERE email = ?");
    $checkStmt->execute([$email]);
    $existingUser = $checkStmt->fetch();
    
    if ($existingUser) {
        // User exists - verify password
        if (password_verify($password, $existingUser['password'])) {
            // Password matches - update last login
            $updateStmt = $pdo->prepare("UPDATE login SET last_login = NOW() WHERE email = ?");
            $updateStmt->execute([$email]);
            
            echo json_encode([
                'success' => true, 
                'message' => 'Login successful! Welcome back.',
                'action' => 'login_success'
            ]);
        } else {
            // Password doesn't match
            echo json_encode([
                'success' => false, 
                'message' => 'Incorrect password. Please try again.',
                'action' => 'password_mismatch'
            ]);
            exit;
        }
    } else {
        // New user - create account
        $insertStmt = $pdo->prepare("INSERT INTO login (email, password, created_at, last_login) VALUES (?, ?, NOW(), NOW())");
        $insertStmt->execute([$email, $hashedPassword]);
        
        echo json_encode([
            'success' => true, 
            'message' => 'Account created successfully! Welcome to EventHub.',
            'action' => 'account_created'
        ]);
    }
    
} catch (PDOException $e) {
    error_log("Database error in login_save.php: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error occurred']);
} catch (Exception $e) {
    error_log("General error in login_save.php: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred while processing your request']);
}
?>
