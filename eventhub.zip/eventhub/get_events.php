<?php
header('Content-Type: application/json');
require_once 'config.php';

try {
    // Fetch all events from newevent table
    $sql = "SELECT * FROM newevent ORDER BY created_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $events = $stmt->fetchAll();
    
    echo json_encode(['success' => true, 'events' => $events]);
    
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
