
<?php
require_once 'config.php';

if (!isset($_GET['id'])) {
    echo json_encode(['success' => false, 'message' => 'No event ID']);
    exit;
}

$id = intval($_GET['id']);
$stmt = $pdo->prepare("SELECT * FROM newevent WHERE id = ?");
$stmt->execute([$id]);
$event = $stmt->fetch(PDO::FETCH_ASSOC);

if ($event) {
    echo json_encode(['success' => true, 'event' => $event]);
} else {
    echo json_encode(['success' => false, 'message' => 'Event not found']);
}
?>