<?php
// Test database connection and table creation
echo "<h2>Event Management System - Setup Test</h2>";

// Test database connection
echo "<h3>1. Testing Database Connection</h3>";
try {
    require_once 'config.php';
    echo "✅ Database connection successful!<br>";
    echo "Connected to database: event<br>";
} catch(Exception $e) {
    echo "❌ Database connection failed: " . $e->getMessage() . "<br>";
    exit;
}

// Test table creation
echo "<h3>2. Testing Table Creation</h3>";
try {
    require_once 'create_table.php';
    echo "✅ Table creation completed!<br>";
} catch(Exception $e) {
    echo "❌ Table creation failed: " . $e->getMessage() . "<br>";
}

// Test getting events
echo "<h3>3. Testing Event Retrieval</h3>";
try {
    $sql = "SELECT COUNT(*) as count FROM newevent";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetch();
    echo "✅ Events table accessible!<br>";
    echo "Current events in database: " . $result['count'] . "<br>";
} catch(Exception $e) {
    echo "❌ Event retrieval failed: " . $e->getMessage() . "<br>";
}

echo "<h3>4. Next Steps</h3>";
echo "1. Make sure your MySQL server is running<br>";
echo "2. Create a database named 'event' in MySQL<br>";
echo "3. Run this test file: <a href='test_setup.php'>test_setup.php</a><br>";
echo "4. Open admin panel: <a href='admin11.php'>admin11.php</a><br>";
echo "5. Login with email: yash@gmail.com and password: 4325<br>";
echo "6. Go to Event Management section to add/view events<br>";
?>
