<?php
require_once 'config.php';

try {
    // Create newevent table
    $sql = "CREATE TABLE IF NOT EXISTS newevent (
        id INT AUTO_INCREMENT PRIMARY KEY,
        event_name VARCHAR(255) NOT NULL,
        event_date DATE NOT NULL,
        description TEXT,
        location VARCHAR(255) NOT NULL,
        capacity INT NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        status ENUM('planning', 'active', 'registration-open', 'sold-out', 'completed') DEFAULT 'planning',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";
    
    $pdo->exec($sql);
    echo "Table 'newevent' created successfully!<br>";
    
    // Create registrations table
    $sql2 = "CREATE TABLE IF NOT EXISTS registrations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        event_name VARCHAR(255) NOT NULL,
        registration_type ENUM('individual', 'group', 'corporate') NOT NULL,
        first_name VARCHAR(255) NOT NULL,
        last_name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        company VARCHAR(255),
        job_title VARCHAR(255),
        dietary_restrictions TEXT,
        registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'pending',
        amount_paid DECIMAL(10,2) DEFAULT 0.00
    )";
    
    $pdo->exec($sql2);
    echo "Table 'registrations' created successfully!<br>";
    
    // Create login table
    $sql3 = "CREATE TABLE IF NOT EXISTS login (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        source ENUM('client', 'admin') DEFAULT 'client',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_login TIMESTAMP NULL,
        is_active BOOLEAN DEFAULT TRUE
    )";
    
    $pdo->exec($sql3);
    echo "Table 'login' created successfully!";
    
} catch(PDOException $e) {
    echo "Error creating table: " . $e->getMessage();
}
?>
