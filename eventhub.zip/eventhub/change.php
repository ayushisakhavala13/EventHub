<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EventPro - Client Portal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #14b8a6 0%, #047857 100%);
        }
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px -5px rgba(0, 0, 0, 0.1);
        }
        .btn-primary {
            background: linear-gradient(135deg, #14b8a6, #0d9488);
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #0d9488, #0f766e);
            transform: translateY(-1px);
        }
        .nav-item:hover {
            background-color: rgba(20, 184, 166, 0.1);
            color: #0d9488;
        }
        .nav-item.active {
            background-color: #14b8a6;
            color: white;
        }
        .section {
            display: none;
        }
        .section.active {
            display: block;
        }
        .login-container {
            min-height: 100vh;
            background: linear-gradient(135deg, #14b8a6 0%, #047857 100%);
            padding: 1rem;
        }
        
        /* Mobile Navigation */
        .mobile-menu {
            display: none;
        }
        
        .mobile-nav-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 40;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .mobile-nav-menu {
            position: fixed;
            top: 0;
            left: 0;
            width: 280px;
            height: 100vh;
            background: white;
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 50;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
        }
        
        @media (max-width: 480px) {
            .mobile-nav-menu {
                width: 100%;
            }
        }
        
        .mobile-nav-menu.open {
            transform: translateX(0);
        }
        
        @media (max-width: 1024px) {
            .desktop-nav {
                display: none !important;
            }
            
            #mobileMenuBtn {
                display: block !important;
            }
        }
        
        @media (min-width: 1025px) {
            #mobileMenuBtn {
                display: none !important;
            }
            
            .desktop-nav {
                display: flex !important;
            }
        }
        
        @media (max-width: 768px) {
            .mobile-menu {
                display: block;
            }
            
            .login-container {
                padding: 0.5rem;
            }
            
            .card {
                margin: 0.5rem;
            }
        }
        .event-card {
            background: linear-gradient(135deg, #f59e0b 0%, #ef4444 100%);
        }
        .registration-badge {
            background: linear-gradient(135deg, #7dd3fc 0%, #818cf8 100%);
        }
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            z-index: 1000;
        }
        .modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .ticket-modal {
            background: white;
            border-radius: 12px;
            max-width: 500px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body class="bg-gray-50 font-sans">
    <div id="loginScreen" class="login-container flex items-center justify-center">
        <div class="card p-8 w-full max-w-md mx-4">
            <div class="text-center mb-8">
                <h1 class="text-3xl font-bold text-gray-800 mb-2">Welcome Back</h1>
                <p class="text-gray-600">Sign in to your EventHub account</p>
            </div>
            
            <form id="loginForm" class="space-y-6" action="login_save.php" method="post">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                    <input type="email" id="loginEmail" name="email" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent" placeholder="Enter your email" required>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Password</label>
                    <input type="password" name="password" id="loginPassword" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent" placeholder="Enter your password" required>
                </div>
                
                <div class="flex items-center justify-between">
                    <a href="#" class="text-sm text-teal-600 hover:text-teal-800"></a>
                </div>
                
                <button type="submit" class="w-full btn-primary text-white py-3 rounded-lg font-medium">
                    Sign In
                </button>
                
                <div class="text-center">
                    <p class="text-sm text-gray-600"><a href="#" class="text-teal-600 hover:text-teal-800"></a></p>
                </div>
            </form>
        </div>
    </div>

    <div id="mainApp" class="hidden">
        <header class="bg-white shadow-sm border-b">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center py-3 sm:py-4">
                    <div class="flex items-center">
                        <!-- Mobile Menu Button -->
                        <button id="mobileMenuBtn" class="lg:hidden mr-3 text-gray-600 hover:text-teal-600 focus:outline-none p-2 rounded-lg hover:bg-gray-100 transition-colors">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                            </svg>
                        </button>
                        
                        <h1 class="text-xl sm:text-2xl font-bold text-teal-600">EventHub</h1>
                        <span class="hidden sm:inline ml-2 text-gray-500">Client Portal</span>
                    </div>
                    
                    <!-- Desktop Navigation -->
                    <nav class="hidden lg:flex space-x-1 desktop-nav">
                        <button onclick="showSection('home')" class="nav-item px-3 lg:px-4 py-2 rounded-lg transition-all duration-200 text-sm lg:text-base">🏠 Home</button>
                        <button onclick="showSection('events')" class="nav-item px-3 lg:px-4 py-2 rounded-lg transition-all duration-200 text-sm lg:text-base">📅 Events</button>
                        <button onclick="showSection('eventRegistration')" class="nav-item px-3 lg:px-4 py-2 rounded-lg transition-all duration-200 text-sm lg:text-base">📝 Register</button>
                        <button onclick="showSection('myRegistrations')" class="nav-item px-3 lg:px-4 py-2 rounded-lg transition-all duration-200 text-sm lg:text-base">📋 My Registrations</button>
                    </nav>
                    
                    <!-- User Info & Logout -->
                    <div class="flex items-center space-x-2 sm:space-x-4">
                        <span class="hidden sm:inline text-gray-600 text-sm">Welcome, <span id="userName"></span></span>
                        <button onclick="logout()" class="text-red-600 hover:text-red-800 text-sm px-2 py-1 rounded">Logout</button>
                    </div>
                </div>
            </div>
        </header>

        <!-- Mobile Navigation Overlay -->
        <div id="mobileNavOverlay" class="mobile-nav-overlay"></div>
        
        <!-- Mobile Navigation Menu -->
        <div id="mobileNavMenu" class="mobile-nav-menu">
            <div class="p-4 sm:p-6 border-b border-gray-200">
                <div class="flex justify-between items-center">
                    <h2 class="text-lg sm:text-xl font-bold text-teal-600">EventHub</h2>
                    <button id="closeMobileMenu" class="text-gray-500 hover:text-gray-700 p-1">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                </div>
                <p class="text-gray-500 text-xs sm:text-sm mt-1">Client Portal</p>
            </div>
            
            <nav class="p-4 space-y-1">
                <button onclick="showSection('home'); closeMobileNav();" class="w-full text-left px-4 py-3 rounded-lg hover:bg-teal-50 transition-colors flex items-center text-sm sm:text-base">
                    <span class="text-lg sm:text-xl mr-3">🏠</span>
                    <span class="font-medium">Home</span>
                </button>
                
                <button onclick="showSection('events'); closeMobileNav();" class="w-full text-left px-4 py-3 rounded-lg hover:bg-teal-50 transition-colors flex items-center text-sm sm:text-base">
                    <span class="text-lg sm:text-xl mr-3">📅</span>
                    <span class="font-medium">Events</span>
                </button>
                
                <button onclick="showSection('eventRegistration'); closeMobileNav();" class="w-full text-left px-4 py-3 rounded-lg hover:bg-teal-50 transition-colors flex items-center text-sm sm:text-base">
                    <span class="text-lg sm:text-xl mr-3">📝</span>
                    <span class="font-medium">Register</span>
                </button>
                
                <button onclick="showSection('myRegistrations'); closeMobileNav();" class="w-full text-left px-4 py-3 rounded-lg hover:bg-teal-50 transition-colors flex items-center text-sm sm:text-base">
                    <span class="text-lg sm:text-xl mr-3">📋</span>
                    <span class="font-medium">My Registrations</span>
                </button>
            </nav>
            
            <div class="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-200 bg-gray-50">
                <div class="text-center text-xs sm:text-sm text-gray-500 mb-3">
                    Welcome, <span id="mobileUserName" class="font-medium text-teal-600"></span>
                </div>
                <button onclick="logout(); closeMobileNav();" class="w-full bg-red-500 text-white py-2 px-4 rounded-lg hover:bg-red-600 transition-colors text-sm font-medium">
                    Logout
                </button>
            </div>
        </div>

        <div id="home" class="section active">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6 lg:py-8">
                <div class="gradient-bg rounded-xl sm:rounded-2xl p-4 sm:p-6 lg:p-8 text-white mb-6 sm:mb-8">
                    <div class="max-w-3xl">
                        <h2 class="text-2xl sm:text-3xl lg:text-4xl font-bold mb-3 sm:mb-4">Discover Amazing Events</h2>
                        <p class="text-base sm:text-lg lg:text-xl mb-4 sm:mb-6">Join thousands of professionals in networking, learning, and growing together at our premium events.</p>
                        <button onclick="showSection('events')" class="bg-white text-teal-600 px-4 sm:px-6 py-2 sm:py-3 rounded-lg font-medium hover:bg-gray-100 transition-colors text-sm sm:text-base">
                            Explore Events
                        </button>
                    </div>
                </div>

                <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 lg:gap-6 mb-6 sm:mb-8">
                    <div class="card p-3 sm:p-4 lg:p-6 text-center">
                        <div class="text-2xl sm:text-3xl mb-2">🎯</div>
                        <h3 class="text-lg sm:text-xl lg:text-2xl font-bold text-gray-800" id="activeEventsCount">0</h3>
                        <p class="text-xs sm:text-sm text-gray-600">Active Events</p>
                    </div>
                    <div class="card p-3 sm:p-4 lg:p-6 text-center">
                        <div class="text-2xl sm:text-3xl mb-2">📅</div>
                        <h3 class="text-lg sm:text-xl lg:text-2xl font-bold text-gray-800" id="totalEventsCount">0</h3>
                        <p class="text-xs sm:text-sm text-gray-600">Total Events</p>
                    </div>
                    <div class="card p-3 sm:p-4 lg:p-6 text-center">
                        <div class="text-2xl sm:text-3xl mb-2">👥</div>
                        <h3 class="text-lg sm:text-xl lg:text-2xl font-bold text-gray-800" id="totalRegistrationsCount">0</h3>
                        <p class="text-xs sm:text-sm text-gray-600">Total Registrations</p>
                    </div>
                    <div class="card p-3 sm:p-4 lg:p-6 text-center">
                        <div class="text-2xl sm:text-3xl mb-2">⭐</div>
                        <h3 class="text-lg sm:text-xl lg:text-2xl font-bold text-gray-800">4.7/5</h3>
                        <p class="text-xs sm:text-sm text-gray-600">Average Rating</p>
                    </div>
                </div>

                <div class="card p-4 sm:p-6 lg:p-8">
                    <h3 class="text-xl sm:text-2xl font-bold text-gray-800 mb-4 sm:mb-6 text-center">What Our Attendees Say</h3>
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                        <div class="p-4 sm:p-6 bg-gray-50 rounded-lg">
                            <p class="text-sm sm:text-base text-gray-600 mb-3 sm:mb-4">"Amazing networking opportunities and excellent speakers. Highly recommend!"</p>
                            <div class="flex items-center">
                                <div class="w-8 h-8 sm:w-10 sm:h-10 bg-teal-500 rounded-full flex items-center justify-center text-white font-bold mr-3 text-sm sm:text-base">A</div>
                                <div>
                                    <p class="font-medium text-sm sm:text-base">Ayushi Sakhavala</p>
                                    <p class="text-xs sm:text-sm text-gray-500">Owner & Founder</p>
                                </div>
                            </div>
                        </div>
                        <div class="p-4 sm:p-6 bg-gray-50 rounded-lg">
                            <p class="text-sm sm:text-base text-gray-600 mb-3 sm:mb-4">"Professional organization and valuable content. Worth every penny!"</p>
                            <div class="flex items-center">
                                <div class="w-8 h-8 sm:w-10 sm:h-10 bg-emerald-500 rounded-full flex items-center justify-center text-white font-bold mr-3 text-sm sm:text-base">B</div>
                                <div>
                                    <p class="font-medium text-sm sm:text-base">Bharat Pipliya</p>
                                    <p class="text-xs sm:text-sm text-gray-500">Software Engineer & Co-Founder</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="events" class="section">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6 lg:py-8">
                <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 sm:mb-8 gap-4">
                    <h2 class="text-2xl sm:text-3xl font-bold text-gray-800">All Events</h2>
                    <div class="w-full sm:w-auto">
                        <input type="text" placeholder="Search events..." class="w-full sm:w-64 px-3 sm:px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 text-sm sm:text-base">
                    </div>
                </div>

                <div id="eventsContainer" class="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 lg:gap-8">
                    <div class="text-center py-8">
                        <div class="animate-spin rounded-full h-8 w-8 sm:h-12 sm:w-12 border-b-2 border-teal-600 mx-auto"></div>
                        <p class="mt-4 text-gray-600 text-sm sm:text-base">Loading events...</p>
                    </div>
                </div>
            </div>
        </div>

        <div id="eventRegistration" class="section">
            <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6 lg:py-8">
                <div class="card p-4 sm:p-6 lg:p-8">
                    <h2 class="text-2xl sm:text-3xl font-bold text-gray-800 mb-6 sm:mb-8">Event Registration</h2>
                    
                    <form id="registrationForm" class="space-y-4 sm:space-y-6">
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Select Event</label>
                                <select id="selectedEvent" class="w-full px-3 sm:px-4 py-2 sm:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm sm:text-base" required>
                                    <option value="">Choose an event...</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Registration Type</label>
                                <select name="registration_type" class="w-full px-3 sm:px-4 py-2 sm:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm sm:text-base" required>
                                    <option value="individual">Individual</option>
                                    <option value="group">Group (3+ people)</option>
                                    <option value="corporate">Corporate</option>
                                </select>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                                <input type="text" name="first_name" class="w-full px-3 sm:px-4 py-2 sm:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm sm:text-base" required>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                                <input type="text" name="last_name" class="w-full px-3 sm:px-4 py-2 sm:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm sm:text-base" required>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                                <input type="email" name="email" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent" required>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                                <input type="tel" name="phone" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent" required>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Company</label>
                                <input type="text" name="company" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Job Title</label>
                                <input type="text" name="job_title" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent">
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Dietary Restrictions / Special Requirements</label>
                            <textarea name="dietary_restrictions" rows="3" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent" placeholder="Please let us know about any dietary restrictions or special accommodations needed..."></textarea>
                        </div>

                        <div class="bg-gray-50 p-6 rounded-lg">
                            <h3 class="text-lg font-medium text-gray-800 mb-4">Registration Summary</h3>
                            <div class="space-y-2">
                                <div class="flex justify-between">
                                    <span>Event:</span>
                                    <span id="summaryEvent">Please select an event</span>
                                </div>
                                <div class="flex justify-between">
                                    <span>Price:</span>
                                    <span id="summaryPrice">₹0</span>
                                </div>
                                <div class="flex justify-between font-bold text-lg border-t pt-2">
                                    <span>Total:</span>
                                    <span id="summaryTotal">₹0</span>
                                </div>
                            </div>
                        </div>

                        <div class="flex items-center">
                            <input type="checkbox" id="terms" class="rounded border-gray-300 text-teal-600 focus:ring-teal-500" required>
                            <label for="terms" class="ml-2 text-sm text-gray-600">I agree to the <a href="#" class="text-teal-600 hover:text-teal-800">Terms and Conditions</a> and <a href="#" class="text-teal-600 hover:text-teal-800">Privacy Policy</a></label>
                        </div>

                        <div class="flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-4">
                            <button type="button" class="w-full sm:w-auto px-4 sm:px-6 py-2 sm:py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors text-sm sm:text-base">Cancel</button>
                            <button type="submit" class="btn-primary text-white px-6 sm:px-8 py-2 sm:py-3 rounded-lg font-medium text-sm sm:text-base">Complete Registration</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div id="myRegistrations" class="section">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6 lg:py-8">
                <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 sm:mb-8 gap-4">
                    <h2 class="text-2xl sm:text-3xl font-bold text-gray-800">My Registrations</h2>
                    <button onclick="showSection('eventRegistration')" class="btn-primary text-white px-4 sm:px-6 py-2 sm:py-3 rounded-lg font-medium text-sm sm:text-base w-full sm:w-auto">
                        Register for New Event
                    </button>
                </div>

                <div id="registrationsContainer" class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div class="text-center py-8">
                        <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-600 mx-auto"></div>
                        <p class="mt-4 text-gray-600">Loading your registrations...</p>
                            </div>
                        </div>
                        
                <div id="registrationSummary" class="mt-6 sm:mt-8 card p-4 sm:p-6">
                    <h3 class="text-lg sm:text-xl font-bold text-gray-800 mb-4">Registration Summary</h3>
                    <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                        <div class="text-center p-3 sm:p-4 bg-blue-50 rounded-lg">
                            <div id="totalRegistrations" class="text-xl sm:text-2xl font-bold text-blue-600">0</div>
                            <div class="text-xs sm:text-sm text-gray-600">Total Registrations</div>
                        </div>
                        <div class="text-center p-3 sm:p-4 bg-teal-50 rounded-lg">
                            <div id="confirmedRegistrations" class="text-xl sm:text-2xl font-bold text-teal-600">0</div>
                            <div class="text-xs sm:text-sm text-gray-600">Confirmed</div>
                        </div>
                        <div class="text-center p-3 sm:p-4 bg-yellow-50 rounded-lg">
                            <div id="pendingRegistrations" class="text-xl sm:text-2xl font-bold text-yellow-600">0</div>
                            <div class="text-xs sm:text-sm text-gray-600">Pending</div>
                        </div>
                        <div class="text-center p-3 sm:p-4 bg-gray-50 rounded-lg">
                            <div id="totalSpent" class="text-xl sm:text-2xl font-bold text-gray-600">₹0</div>
                            <div class="text-xs sm:text-sm text-gray-600">Total Spent</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Payment Modal -->
    <div id="paymentModal" class="modal">
        <div class="ticket-modal">
            <div class="p-6">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-2xl font-bold text-gray-800">Complete Payment</h3>
                    <button onclick="closePaymentModal()" class="text-gray-400 hover:text-gray-600 text-2xl">&times;</button>
                </div>
                
                <div class="space-y-6">
                    <!-- Payment Details -->
                    <div class="border-b pb-4">
                        <h4 class="text-lg font-bold text-gray-800" id="paymentEventName">Event Name</h4>
                        <p class="text-gray-600" id="paymentEventDate">Event Date</p>
                        <p class="text-lg font-bold text-teal-600 mt-2" id="paymentAmount">Amount: ₹0</p>
                    </div>
                    
                    <!-- Payment Methods -->
                    <div class="space-y-4">
                        <h5 class="text-lg font-medium text-gray-800">Select Payment Method</h5>
                        
                        <div class="space-y-3">
                            <label class="flex items-center p-4 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                                <input type="radio" name="paymentMethod" value="card" class="mr-3" checked>
                                <div class="flex items-center">
                                    <span class="text-2xl mr-3">💳</span>
                                    <div>
                                        <div class="font-medium">Credit/Debit Card</div>
                                        <div class="text-sm text-gray-500">Pay with your card</div>
                                    </div>
                                </div>
                            </label>
                            
                            <label class="flex items-center p-4 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                                <input type="radio" name="paymentMethod" value="upi" class="mr-3">
                                <div class="flex items-center">
                                    <span class="text-2xl mr-3">📱</span>
                                    <div>
                                        <div class="font-medium">UPI Payment</div>
                                        <div class="text-sm text-gray-500">Pay via UPI apps</div>
                                    </div>
                                </div>
                            </label>
                            
                            <label class="flex items-center p-4 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                                <input type="radio" name="paymentMethod" value="netbanking" class="mr-3">
                                <div class="flex items-center">
                                    <span class="text-2xl mr-3">🏦</span>
                                    <div>
                                        <div class="font-medium">Net Banking</div>
                                        <div class="text-sm text-gray-500">Pay via net banking</div>
                                    </div>
                                </div>
                            </label>
                        </div>
                    </div>
                    
                    <!-- Action Buttons -->
                    <div class="flex space-x-3 pt-4">
                        <button onclick="processPayment()" class="flex-1 bg-green-500 text-white py-3 rounded-lg hover:bg-green-600 transition-colors font-medium">
                            Pay Now
                        </button>
                        <button onclick="closePaymentModal()" class="flex-1 border border-gray-300 text-gray-700 py-3 rounded-lg hover:bg-gray-50 transition-colors">
                            Cancel
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Ticket Popup Modal -->
    <div id="ticketModal" class="modal">
        <div class="ticket-modal">
            <div class="p-6">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-2xl font-bold text-gray-800">Event Ticket</h3>
                    <button onclick="closeTicketModal()" class="text-gray-400 hover:text-gray-600 text-2xl">&times;</button>
                </div>
                
                <div class="space-y-6">
                    <!-- Ticket Header -->
                    <div class="text-center border-b pb-4">
                        <div class="text-4xl mb-2">🎫</div>
                        <h4 class="text-xl font-bold text-gray-800" id="ticketEventName">Event Name</h4>
                        <p class="text-gray-600" id="ticketEventDate">Event Date</p>
                    </div>
                    
                    <!-- Ticket Details -->
                    <div class="space-y-4">
                        <div class="flex justify-between items-center">
                            <span class="text-gray-600">Registration ID:</span>
                            <span class="font-medium" id="ticketRegId">REG-000000</span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-600">Attendee:</span>
                            <span class="font-medium" id="ticketAttendee">Name</span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-600">Email:</span>
                            <span class="font-medium" id="ticketEmail">email@example.com</span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-600">Phone:</span>
                            <span class="font-medium" id="ticketPhone">+91 9876543210</span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-600">Location:</span>
                            <span class="font-medium" id="ticketLocation">Event Location</span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-600">Amount Paid:</span>
                            <span class="font-bold text-teal-600" id="ticketAmount">₹0</span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-600">Status:</span>
                            <span class="px-3 py-1 bg-teal-100 text-teal-800 rounded-full text-sm font-medium" id="ticketStatus">Confirmed</span>
                        </div>
                    </div>
                    
                    <!-- QR Code Placeholder -->
                    <div class="text-center border-t pt-4">
                        <div class="w-32 h-32 bg-gray-100 rounded-lg mx-auto flex items-center justify-center mb-2">
                            <div class="text-gray-400 text-sm">QR Code</div>
                        </div>
                        <p class="text-sm text-gray-500">Show this ticket at the event entrance</p>
                    </div>
                    
                    <!-- Action Buttons -->
                    <div class="flex space-x-3 pt-4">
                        <button onclick="downloadTicket()" class="flex-1 bg-teal-500 text-white py-2 rounded-lg hover:bg-teal-600 transition-colors">
                            Download Ticket
                        </button>
                        <button onclick="closeTicketModal()" class="flex-1 border border-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-50 transition-colors">
                            Close
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Global variable to store user email and registrations
        let currentUserEmail = '';
        let currentRegistrations = [];

        // Login functionality
        document.getElementById('loginForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const email = document.getElementById('loginEmail').value;
            const password = document.getElementById('loginPassword').value;
            
            // Show loading state
            const submitButton = this.querySelector('button[type="submit"]');
            const originalText = submitButton.textContent;
            submitButton.textContent = 'Signing In...';
            submitButton.disabled = true;
            
            // Simple validation
            if (email && password) {
                try {
                    // Create FormData object to send form data
                    const formData = new FormData();
                    formData.append('email', email);
                    formData.append('password', password);
                    
                    // Send data to login_save.php
                    const response = await fetch('login_save.php', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const result = await response.json();
                    
                    if (result.success) {
                        // Show success message based on action
                        if (result.action === 'account_created') {
                            alert('🎉 Account created successfully! Welcome to EventHub.');
                        } else if (result.action === 'login_success') {
                            alert('✅ Login successful! Welcome back to EventHub.');
                        } else {
                            alert('✅ Login successful! Welcome to EventHub.');
                        }
                        
                        // Hide login screen and show main app
                        document.getElementById('loginScreen').classList.add('hidden');
                        document.getElementById('mainApp').classList.remove('hidden');
                        
                        // Set user name and store email
                        const userName = email.split('@')[0];
                        const displayName = userName.charAt(0).toUpperCase() + userName.slice(1);
                        document.getElementById('userName').textContent = displayName;
                        document.getElementById('mobileUserName').textContent = displayName;
                        currentUserEmail = email; // Store email for fetching registrations
                        
                        // Load dashboard stats
                        loadDashboardStats();
                    } else {
                        // Show error message
                        alert('❌ ' + result.message);
                    }
                } catch (error) {
                    console.error('Login error:', error);
                    alert('Login failed. Please try again.');
                }
            } else {
                alert('Please enter valid email and password');
            }
            
            // Reset button state
            submitButton.textContent = originalText;
            submitButton.disabled = false;
        });

        // Navigation functionality
        function showSection(sectionId) {
            // Hide all sections
            const sections = document.querySelectorAll('.section');
            sections.forEach(section => section.classList.remove('active'));
            
            // Show selected section
            document.getElementById(sectionId).classList.add('active');
            
            // Update navigation active state
            const navItems = document.querySelectorAll('.nav-item');
            navItems.forEach(item => item.classList.remove('active'));
            
            // Find and activate the clicked nav item
            const activeNavItems = document.querySelectorAll(`[onclick="showSection('${sectionId}')"]`);
            activeNavItems.forEach(item => item.classList.add('active'));
            
            // Load events when events section is shown
            if (sectionId === 'events') {
                loadEvents();
            }
            
            // Load events for registration form when registration section is shown
            if (sectionId === 'eventRegistration') {
                loadEventsForRegistration();
            }
            
            // Load user registrations when myRegistrations section is shown
            if (sectionId === 'myRegistrations') {
                loadUserRegistrations();
            }
        }

        // Load events from database
        async function loadEvents() {
            try {
                const response = await fetch('get_events.php');
                const result = await response.json();
                
                if (result.success) {
                    displayEvents(result.events);
                } else {
                    document.getElementById('eventsContainer').innerHTML = 
                        '<div class="text-center py-8"><p class="text-red-600">Error loading events: ' + result.message + '</p></div>';
                }
            } catch (error) {
                console.error('Error loading events:', error);
                document.getElementById('eventsContainer').innerHTML = 
                    '<div class="text-center py-8"><p class="text-red-600">Error loading events. Please try again.</p></div>';
            }
        }

        // Load events for registration form
        async function loadEventsForRegistration() {
            try {
                const response = await fetch('get_events.php');
                const result = await response.json();
                
                if (result.success) {
                    populateRegistrationEvents(result.events);
                } else {
                    console.error('Error loading events for registration:', result.message);
                }
            } catch (error) {
                console.error('Error loading events for registration:', error);
            }
        }

        // Populate registration form with events
        function populateRegistrationEvents(events) {
            const eventSelect = document.getElementById('selectedEvent');
            
            // Clear existing options except the first one
            eventSelect.innerHTML = '<option value="">Choose an event...</option>';
            
            // Add events to dropdown
            events.forEach(event => {
                if (event.status !== 'sold-out' && event.status !== 'completed') {
                    const option = document.createElement('option');
                    option.value = event.id;
                    option.textContent = `${event.event_name} - ₹${parseFloat(event.price).toLocaleString()}`;
                    eventSelect.appendChild(option);
                }
            });
        }

        // Load user registrations from database
        async function loadUserRegistrations() {
            try {
                // Use the stored user email
                if (!currentUserEmail) {
                    document.getElementById('registrationsContainer').innerHTML = 
                        '<div class="text-center py-8"><p class="text-red-600">Please login to view your registrations.</p></div>';
                    return;
                }
                
                const response = await fetch(`get_registrations.php?email=${encodeURIComponent(currentUserEmail)}`);
                const result = await response.json();
                
                if (result.success) {
                    currentRegistrations = result.registrations; // Store registrations globally
                    displayUserRegistrations(result.registrations);
                    updateRegistrationSummaryStats(result.registrations);
                } else {
                    document.getElementById('registrationsContainer').innerHTML = 
                        '<div class="text-center py-8"><p class="text-red-600">Error loading registrations: ' + result.message + '</p></div>';
                }
            } catch (error) {
                console.error('Error loading registrations:', error);
                document.getElementById('registrationsContainer').innerHTML = 
                    '<div class="text-center py-8"><p class="text-red-600">Error loading registrations. Please try again.</p></div>';
            }
        }

        // Display user registrations dynamically
        function displayUserRegistrations(registrations) {
            const container = document.getElementById('registrationsContainer');
            
            if (registrations.length === 0) {
                container.innerHTML = '<div class="text-center py-8"><p class="text-gray-600">No registrations found. <a href="#" onclick="showSection(\'eventRegistration\')" class="text-teal-600 hover:text-teal-800">Register for an event</a></p></div>';
                return;
            }
            
            container.innerHTML = registrations.map(registration => {
                const status = getRegistrationStatus(registration.status);
                const statusClass = getRegistrationStatusClass(registration.status);
                const borderClass = getRegistrationBorderClass(registration.status);
                const icon = getEventIcon(registration.event_name);
                const formattedDate = registration.event_date ? new Date(registration.event_date).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                }) : 'Date TBD';
                
                return `
                    <div class="card p-6 ${borderClass}">
                        <div class="flex justify-between items-start mb-4">
                            <div>
                                <h3 class="text-xl font-bold text-gray-800">${registration.event_name}</h3>
                                <p class="text-gray-600">${formattedDate}</p>
                            </div>
                            <span class="px-3 py-1 ${statusClass} rounded-full text-sm font-medium">${status}</span>
                        </div>
                        
                        <div class="space-y-2 mb-4">
                            <div class="flex items-center text-sm text-gray-600">
                                <span class="mr-2">📍</span>
                                <span>${registration.location || 'Location TBD'}</span>
                            </div>
                            <div class="flex items-center text-sm text-gray-600">
                                <span class="mr-2">🎫</span>
                                <span>Registration ID: REG-${registration.id.toString().padStart(6, '0')}</span>
                            </div>
                            <div class="flex items-center text-sm text-gray-600">
                                <span class="mr-2">💰</span>
                                <span>Amount: ₹${parseFloat(registration.amount_paid).toLocaleString()}</span>
                            </div>
                            <div class="flex items-center text-sm text-gray-600">
                                <span class="mr-2">📅</span>
                                <span>Registered: ${new Date(registration.registration_date).toLocaleDateString()}</span>
                            </div>
                        </div>
                        
                        <div class="flex space-x-3">
                            ${getRegistrationButtons(registration.status, registration.id)}
                        </div>
                    </div>
                `;
            }).join('');
        }

        // Get registration status text
        function getRegistrationStatus(status) {
            switch(status) {
                case 'confirmed':
                    return 'Confirmed';
                case 'pending':
                    return 'Pending';
                case 'paid':
                    return 'Payment Completed';
                case 'cancelled':
                    return 'Cancelled';
                default:
                    return 'Unknown';
            }
        }

        // Get registration status CSS classes
        function getRegistrationStatusClass(status) {
            switch(status) {
                case 'confirmed':
                    return 'bg-teal-100 text-teal-800';
                case 'pending':
                    return 'bg-yellow-100 text-yellow-800';
                case 'paid':
                    return 'bg-blue-100 text-blue-800';
                case 'cancelled':
                    return 'bg-red-100 text-red-800';
                default:
                    return 'bg-gray-100 text-gray-800';
            }
        }

        // Get registration border CSS classes
        function getRegistrationBorderClass(status) {
            switch(status) {
                case 'confirmed':
                    return 'border-l-4 border-teal-500';
                case 'pending':
                    return 'border-l-4 border-yellow-500';
                case 'paid':
                    return 'border-l-4 border-blue-500';
                case 'cancelled':
                    return 'border-l-4 border-red-500';
                default:
                    return 'border-l-4 border-gray-400';
            }
        }

        // Get registration action buttons based on status
        function getRegistrationButtons(status, id) {
            switch(status) {
                case 'confirmed':
                    return `
                        <div class="flex justify-center w-full space-x-3">
                            <button onclick="showTicketPopup(${id})" class="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">View Ticket</button>
                            <button onclick="downloadReceipt(${id})" class="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">Download Receipt</button>
                        </div>
                    `;
                case 'pending':
                    return `
                        <button onclick="completePayment(${id})" class="flex-1 bg-green-500 text-white py-2 rounded-lg hover:bg-green-600 transition-colors">Complete Payment</button>
                        <button class="flex-1 border border-red-300 text-red-700 py-2 rounded-lg hover:bg-red-50 transition-colors" onclick="cancelRegistration(${id}, this)">Cancel Registration</button>
                    `;
                case 'paid':
                    return `
                        <div class="flex justify-center w-full">
                            <span class="px-4 py-2 bg-blue-100 text-blue-800 rounded-lg text-sm font-medium">Awaiting Admin Confirmation</span>
                        </div>
                    `;
                case 'cancelled':
                    return `
                        <button class="flex-1 bg-gray-500 text-white py-2 rounded-lg cursor-not-allowed" disabled>Registration Cancelled</button>
                        <button class="flex-1 border border-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-50 transition-colors">View Details</button>
                    `;
                default:
                    return `
                        <button class="flex-1 bg-gray-500 text-white py-2 rounded-lg cursor-not-allowed" disabled>No Actions</button>
                    `;
            }
        }

        // Update registration summary statistics
        function updateRegistrationSummaryStats(registrations) {
            const total = registrations.length;
            const confirmed = registrations.filter(r => r.status === 'confirmed').length;
            const pending = registrations.filter(r => r.status === 'pending').length;
            const totalSpent = registrations.reduce((sum, r) => sum + parseFloat(r.amount_paid || 0), 0);
            
            document.getElementById('totalRegistrations').textContent = total;
            document.getElementById('confirmedRegistrations').textContent = confirmed;
            document.getElementById('pendingRegistrations').textContent = pending;
            document.getElementById('totalSpent').textContent = `₹${totalSpent.toLocaleString()}`;
        }

        // Display events dynamically
        function displayEvents(events) {
            const container = document.getElementById('eventsContainer');
            
            if (events.length === 0) {
                container.innerHTML = '<div class="text-center py-8"><p class="text-gray-600">No events available at the moment.</p></div>';
                return;
            }
            
            container.innerHTML = events.map(event => {
                const status = getEventStatus(event);
                const statusClass = getStatusClass(event.status);
                const icon = getEventIcon(event.event_name);
                const formattedDate = new Date(event.event_date).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                });
                
                return `
                    <div class="card p-6">
                        <div class="flex items-start justify-between mb-4">
                            <div class="flex items-center">
                                <div class="w-16 h-16 ${icon.bg} rounded-lg flex items-center justify-center text-white text-2xl mr-4">${icon.emoji}</div>
                                <div>
                                    <h3 class="text-xl font-bold text-gray-800">${event.event_name}</h3>
                                    <p class="text-gray-600">${formattedDate}</p>
                                </div>
                            </div>
                            <span class="px-3 py-1 ${statusClass} rounded-full text-sm font-medium">${status}</span>
                        </div>
                        
                        <p class="text-gray-600 mb-4">${event.description || 'Join us for an amazing event experience.'}</p>
                        
                        <div class="space-y-2 mb-4">
                            <div class="flex items-center text-sm text-gray-600">
                                <span class="mr-2">📍</span>
                                <span>${event.location}</span>
                            </div>
                            <div class="flex items-center text-sm text-gray-600">
                                <span class="mr-2">👥</span>
                                <span>0/${event.capacity} registered</span>
                            </div>
                        </div>
                        
                        <div class="flex justify-between items-center">
                            <span class="text-2xl font-bold ${event.status === 'sold-out' ? 'text-gray-400' : 'text-teal-600'}">₹${parseFloat(event.price).toLocaleString()}</span>
                            ${event.status === 'sold-out' ? 
                                '<button disabled class="bg-gray-300 text-gray-500 px-6 py-2 rounded-lg cursor-not-allowed">Sold Out</button>' :
                                `<button onclick="registerForEvent('${event.id}')" class="btn-primary text-white px-6 py-2 rounded-lg">Register Now</button>`
                            }
                        </div>
                    </div>
                `;
            }).join('');
        }

        // Get event status based on database status
        function getEventStatus(event) {
            switch(event.status) {
                case 'active':
                case 'registration-open':
                    return 'Available';
                case 'sold-out':
                    return 'Sold Out';
                case 'completed':
                    return 'Completed';
                default:
                    return 'Planning';
            }
        }

        // Get status CSS classes
        function getStatusClass(status) {
            switch(status) {
                case 'active':
                case 'registration-open':
                    return 'bg-green-100 text-green-800';
                case 'sold-out':
                    return 'bg-red-100 text-red-800';
                case 'completed':
                    return 'bg-gray-100 text-gray-800';
                default:
                    return 'bg-yellow-100 text-yellow-800';
            }
        }

        // Get event icon based on event name
        function getEventIcon(eventName) {
            const name = eventName.toLowerCase();
            if (name.includes('tech') || name.includes('technology')) {
                return { emoji: '💻', bg: 'bg-blue-500' };
            } else if (name.includes('marketing')) {
                return { emoji: '📈', bg: 'bg-purple-500' };
            } else if (name.includes('design')) {
                return { emoji: '🎨', bg: 'bg-green-500' };
            } else if (name.includes('business') || name.includes('leadership')) {
                return { emoji: '💼', bg: 'bg-red-500' };
            } else {
                return { emoji: '🎯', bg: 'bg-teal-500' };
            }
        }

        // Event registration functionality
        function registerForEvent(eventId) {
            showSection('eventRegistration');
            
            // Pre-select the event in the registration form
            const eventSelect = document.getElementById('selectedEvent');
            eventSelect.value = eventId;
            updateRegistrationSummary();
        }

        // Update registration summary
        function updateRegistrationSummary() {
            const eventSelect = document.getElementById('selectedEvent');
            const selectedOption = eventSelect.options[eventSelect.selectedIndex];
            
            if (selectedOption.value) {
                const eventText = selectedOption.text;
                // Look for the Rupee symbol '₹' in the event text
                const priceMatch = eventText.match(/₹([\d,]+)/);
                const price = priceMatch ? `₹${priceMatch[1]}` : '₹0';
                
                document.getElementById('summaryEvent').textContent = eventText.split(' - ')[0];
                document.getElementById('summaryPrice').textContent = price;
                document.getElementById('summaryTotal').textContent = price;
            } else {
                document.getElementById('summaryEvent').textContent = 'Please select an event';
                document.getElementById('summaryPrice').textContent = '₹0';
                document.getElementById('summaryTotal').textContent = '₹0';
            }
        }

        // Event listeners
        document.getElementById('selectedEvent').addEventListener('change', updateRegistrationSummary);

        document.getElementById('registrationForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(this);
            const selectedEvent = document.getElementById('selectedEvent');
            const eventName = selectedEvent.options[selectedEvent.selectedIndex].text.split(' - ')[0];
            const eventPrice = document.getElementById('summaryTotal').textContent;
            
            // Add event name and amount to form data
            formData.append('event_name', eventName);
            formData.append('amount_paid', eventPrice.replace('₹', '').replace(',', ''));
            
            try {
                const response = await fetch('save_registration.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    alert('Registration completed successfully! Registration ID: ' + result.registration_id);
                    this.reset();
                    updateRegistrationSummary();
            showSection('myRegistrations');
                } else {
                    alert('Registration failed: ' + result.message);
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Registration failed. Please try again.');
            }
        });

        // Mobile Navigation Functions
        function openMobileNav() {
            const overlay = document.getElementById('mobileNavOverlay');
            const menu = document.getElementById('mobileNavMenu');
            
            if (overlay && menu) {
                overlay.style.display = 'block';
                menu.classList.add('open');
                document.body.style.overflow = 'hidden'; // Prevent background scrolling
                
                // Add smooth animation
                setTimeout(() => {
                    overlay.style.opacity = '1';
                }, 10);
            }
        }
        
        function closeMobileNav() {
            const overlay = document.getElementById('mobileNavOverlay');
            const menu = document.getElementById('mobileNavMenu');
            
            if (overlay && menu) {
                overlay.style.opacity = '0';
                menu.classList.remove('open');
                document.body.style.overflow = 'auto'; // Restore scrolling
                
                // Hide overlay after animation
                setTimeout(() => {
                    overlay.style.display = 'none';
                }, 300);
            }
        }

        // Logout functionality
        function logout() {
            if (confirm('Are you sure you want to logout?')) {
                document.getElementById('mainApp').classList.add('hidden');
                document.getElementById('loginScreen').classList.remove('hidden');
                document.getElementById('loginForm').reset();
                closeMobileNav(); // Close mobile nav if open
            }
        }

        // Cancel registration functionality
        async function cancelRegistration(id, btn) {
            if (!confirm('Are you sure you want to cancel this registration?')) return;
            btn.disabled = true;
            btn.textContent = 'Cancelling...';
            try {
                const response = await fetch('delete_registration.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `id=${encodeURIComponent(id)}`
                });
                const result = await response.json();
                if (result.success) {
                    // Reload registrations
                    loadUserRegistrations();
                } else {
                    alert('Failed to cancel registration: ' + result.message);
                    btn.disabled = false;
                    btn.textContent = 'Cancel Registration';
                }
            } catch (err) {
                alert('Error cancelling registration.');
                btn.disabled = false;
                btn.textContent = 'Cancel Registration';
            }
        }

        // Fetch all dashboard stats from backend
async function loadDashboardStats() {
    try {
        const res = await fetch('get_dashboard_stats.php');
        const data = await res.json();
        if (data.success) {
            document.getElementById('activeEventsCount').textContent = data.active_events;
            document.getElementById('totalEventsCount').textContent = data.total_events;
            document.getElementById('totalRegistrationsCount').textContent = data.total_registrations;
        }
    } catch (e) {
        document.getElementById('activeEventsCount').textContent = '0';
        document.getElementById('totalEventsCount').textContent = '0';
        document.getElementById('totalRegistrationsCount').textContent = '0';
    }
}

        // Ticket popup functionality
        function showTicketPopup(registrationId) {
            // Find the registration data
            const registration = findRegistrationById(registrationId);
            if (!registration) {
                alert('Registration not found');
                return;
            }
            
            // Populate ticket modal with registration data
            document.getElementById('ticketEventName').textContent = registration.event_name;
            document.getElementById('ticketEventDate').textContent = registration.event_date ? 
                new Date(registration.event_date).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                }) : 'Date TBD';
            document.getElementById('ticketRegId').textContent = `REG-${registration.id.toString().padStart(6, '0')}`;
            document.getElementById('ticketAttendee').textContent = `${registration.first_name} ${registration.last_name}`;
            document.getElementById('ticketEmail').textContent = registration.email;
            document.getElementById('ticketPhone').textContent = registration.phone || 'Not provided';
            document.getElementById('ticketLocation').textContent = registration.location || 'Location TBD';
            document.getElementById('ticketAmount').textContent = `₹${parseFloat(registration.amount_paid).toLocaleString()}`;
            
            // Update status badge
            const statusElement = document.getElementById('ticketStatus');
            statusElement.textContent = getRegistrationStatus(registration.status);
            statusElement.className = `px-3 py-1 rounded-full text-sm font-medium ${getRegistrationStatusClass(registration.status)}`;
            
            // Show modal
            document.getElementById('ticketModal').classList.add('active');
        }
        
        function closeTicketModal() {
            document.getElementById('ticketModal').classList.remove('active');
        }
        
        function downloadTicket() {
            // Simple download functionality - in a real app, this would generate a PDF
            const ticketData = {
                event: document.getElementById('ticketEventName').textContent,
                date: document.getElementById('ticketEventDate').textContent,
                regId: document.getElementById('ticketRegId').textContent,
                attendee: document.getElementById('ticketAttendee').textContent,
                email: document.getElementById('ticketEmail').textContent,
                phone: document.getElementById('ticketPhone').textContent,
                location: document.getElementById('ticketLocation').textContent,
                amount: document.getElementById('ticketAmount').textContent,
                status: document.getElementById('ticketStatus').textContent
            };
            
            // Create a simple text file with ticket details
            const ticketText = `
EVENT TICKET
============

Event: ${ticketData.event}
Date: ${ticketData.date}
Registration ID: ${ticketData.regId}
Attendee: ${ticketData.attendee}
Email: ${ticketData.email}
Phone: ${ticketData.phone}
Location: ${ticketData.location}
Amount Paid: ${ticketData.amount}
Status: ${ticketData.status}

Please bring this ticket to the event entrance.
            `;
            
            const blob = new Blob([ticketText], { type: 'text/plain' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `ticket-${ticketData.regId}.txt`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            
            alert('Ticket downloaded successfully!');
        }
        
        function findRegistrationById(id) {
            // Find registration from the stored registrations data
            const registration = currentRegistrations.find(reg => reg.id == id);
            if (registration) {
                return registration;
            }
            
            // Fallback to mock data if not found
            return {
                id: id,
                event_name: 'Sample Event',
                event_date: new Date().toISOString().split('T')[0],
                first_name: 'John',
                last_name: 'Doe',
                email: 'john@example.com',
                phone: '+91 9876543210',
                location: 'Convention Center',
                amount_paid: '1500',
                status: 'confirmed'
            };
        }
        
        // Complete Payment functionality
        function completePayment(registrationId) {
            // Find the registration data
            const registration = findRegistrationById(registrationId);
            if (!registration) {
                alert('Registration not found');
                return;
            }
            
            // Populate payment modal with registration data
            document.getElementById('paymentEventName').textContent = registration.event_name;
            document.getElementById('paymentEventDate').textContent = registration.event_date ? 
                new Date(registration.event_date).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                }) : 'Date TBD';
            document.getElementById('paymentAmount').textContent = `Amount: ₹${parseFloat(registration.amount_paid).toLocaleString()}`;
            
            // Store registration ID for payment processing
            document.getElementById('paymentModal').setAttribute('data-registration-id', registrationId);
            
            // Show payment modal
            document.getElementById('paymentModal').classList.add('active');
        }
        
        function closePaymentModal() {
            document.getElementById('paymentModal').classList.remove('active');
        }
        
        async function processPayment() {
            const registrationId = document.getElementById('paymentModal').getAttribute('data-registration-id');
            const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked').value;
            
            if (!registrationId) {
                alert('Registration ID not found');
                return;
            }
            
            // Show loading state
            const payButton = document.querySelector('button[onclick="processPayment()"]');
            const originalText = payButton.textContent;
            payButton.textContent = 'Processing...';
            payButton.disabled = true;
            
            try {
                // Simulate payment processing
                await new Promise(resolve => setTimeout(resolve, 2000));
                
                // Update registration status to 'paid' (new status)
                const formData = new FormData();
                formData.append('id', registrationId);
                formData.append('status', 'paid');
                formData.append('payment_method', paymentMethod);
                
                const response = await fetch('update_registration_status.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    alert('Payment completed successfully! Your registration is now pending admin confirmation.');
                    closePaymentModal();
                    // Reload registrations to show updated status
                    loadUserRegistrations();
                } else {
                    alert('Payment failed: ' + (result.message || 'Unknown error'));
                }
            } catch (error) {
                alert('Payment failed: ' + error.message);
            } finally {
                // Reset button state
                payButton.textContent = originalText;
                payButton.disabled = false;
            }
        }
        
        // Close modal when clicking outside
        document.getElementById('ticketModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeTicketModal();
            }
        });
        
        document.getElementById('paymentModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closePaymentModal();
            }
        });

        function downloadReceipt(registrationId) {
            const reg = findRegistrationById(registrationId);
            if (!reg) {
                alert('Registration not found');
                return;
            }
            const receipt = `
PAYMENT RECEIPT
================

Receipt No: RCPT-${String(registrationId).padStart(6, '0')}
Date: ${new Date().toLocaleString()}

Event: ${reg.event_name}
Event Date: ${reg.event_date ? new Date(reg.event_date).toLocaleDateString() : 'Date TBD'}
Location: ${reg.location || 'N/A'}

Attendee: ${reg.first_name} ${reg.last_name}
Email: ${reg.email}
Phone: ${reg.phone || 'N/A'}

Amount Paid: ₹${parseFloat(reg.amount_paid || 0).toLocaleString()}
Status: ${getRegistrationStatus(reg.status)}

Thank you for your payment.
`; 
            const blob = new Blob([receipt], { type: 'text/plain' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `receipt-RCPT-${String(registrationId).padStart(6, '0')}.txt`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        }

document.addEventListener('DOMContentLoaded', function() {
    // Set home as active by default
    const homeNavItems = document.querySelectorAll(`[onclick="showSection('home')"]`);
    homeNavItems.forEach(item => item.classList.add('active'));

    loadDashboardStats();
    
    // Mobile navigation event listeners
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const closeMobileMenuBtn = document.getElementById('closeMobileMenu');
    const mobileNavOverlay = document.getElementById('mobileNavOverlay');
    
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            openMobileNav();
        });
    }
    
    if (closeMobileMenuBtn) {
        closeMobileMenuBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            closeMobileNav();
        });
    }
    
    if (mobileNavOverlay) {
        mobileNavOverlay.addEventListener('click', function(e) {
            e.preventDefault();
            closeMobileNav();
        });
    }
    
    // Close mobile nav on window resize to desktop size
    window.addEventListener('resize', function() {
        if (window.innerWidth >= 1024) {
            closeMobileNav();
        }
    });
    
    // Debug function to test mobile nav
    function testMobileNav() {
        console.log('Testing mobile navigation...');
        console.log('Mobile menu button:', document.getElementById('mobileMenuBtn'));
        console.log('Mobile nav menu:', document.getElementById('mobileNavMenu'));
        console.log('Mobile nav overlay:', document.getElementById('mobileNavOverlay'));
        console.log('Window width:', window.innerWidth);
    }
    
    // Make test function available globally for debugging
    window.testMobileNav = testMobileNav;
    
    // Update mobile username when login happens
    const userNameElement = document.getElementById('userName');
    const mobileUserNameElement = document.getElementById('mobileUserName');
    if (userNameElement && mobileUserNameElement) {
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'childList' || mutation.type === 'characterData') {
                    mobileUserNameElement.textContent = userNameElement.textContent;
                }
            });
        });
        observer.observe(userNameElement, { childList: true, characterData: true, subtree: true });
    }
});

// Search events functionality
document.querySelector('input[placeholder="Search events..."]').addEventListener('input', function(e) {
    const searchTerm = e.target.value.trim().toLowerCase();
    // Fetch all events from backend (or use already loaded events if available)
    fetch('get_events.php')
        .then(res => res.json())
        .then(result => {
            if (result.success) {
                // Filter events by name, description, or location
                const filtered = result.events.filter(event =>
                    event.event_name.toLowerCase().includes(searchTerm) ||
                    (event.description && event.description.toLowerCase().includes(searchTerm)) ||
                    (event.location && event.location.toLowerCase().includes(searchTerm))
                );
                displayEvents(filtered);
            }
        });
});
    </script>
</body>
</html>