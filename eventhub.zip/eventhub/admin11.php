<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            background-color: #0f172a; /* Fallback for older browsers */
            background-image: linear-gradient(135deg, #1e3a8a, #0f172a);
            color: #d1d5db; /* Default light text color */
        }
        .sidebar-item:hover {
            background-color: #1f2937; /* gray-800 */
            transform: translateX(4px);
        }
        .sidebar-item {
            transition: all 0.3s ease;
        }
        .content-section {
            display: none;
        }
        .content-section.active {
            display: block;
        }
        .card {
            background: #111827; /* gray-900 */
            border-radius: 12px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.4);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            border: 1px solid #374151; /* gray-700 */
        }
        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px -5px rgba(0, 0, 0, 0.4);
        }
        .btn-primary {
            background: linear-gradient(135deg, #6366f1, #4f46e5);
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #4f46e5, #4338ca);
            transform: translateY(-1px);
        }
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            z-index: 1000;
        }
        .modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .stats-card {
            background: linear-gradient(135deg, #4338ca 0%, #312e81 100%);
        }
        .login-container {
            min-height: 100vh;
            padding: 1rem;
        }
        
        /* Mobile responsive styles */
        .sidebar {
            transition: transform 0.3s ease;
        }
        
        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0 !important;
            }
            
            #mobileMenuBtn {
                display: block !important;
            }
        }
        
        @media (min-width: 1025px) {
            .sidebar {
                transform: translateX(0) !important;
            }
            
            .main-content {
                margin-left: 16rem !important;
            }
            
            #mobileMenuBtn {
                display: none !important;
            }
        }
        
        @media (max-width: 768px) {
            .login-container {
                padding: 0.5rem;
            }
            
            .card {
                margin: 0.5rem;
            }
            
            .sidebar {
                width: 280px;
            }
        }
        
        @media (max-width: 480px) {
            .sidebar {
                width: 100%;
            }
        }
        
        /* Dark mode form inputs */
        .dark-input {
            background-color: #374151; /* gray-700 */
            border: 1px solid #4b5563; /* gray-600 */
            color: #f3f4f6; /* gray-100 */
        }
        .dark-input::placeholder {
            color: #9ca3af; /* gray-400 */
        }
        .dark-input:focus {
            ring-offset-color: #111827; /* gray-900 */
            --tw-ring-color: #6366f1; /* indigo-500 */
        }
    </style>
</head>
<body class="font-sans">

    <div id="loginScreen" class="login-container flex items-center justify-center">
        <div class="card p-4 sm:p-6 lg:p-8 w-full max-w-md mx-4">
            <div class="text-center mb-6 sm:mb-8">
                <h1 class="text-2xl sm:text-3xl font-bold text-gray-100 mb-2">Admin Login</h1>
                <p class="text-gray-400 text-sm sm:text-base">Please sign in to continue</p>
            </div>
            
            <form id="adminLoginForm" class="space-y-4 sm:space-y-6">
                <div>
                    <label class="block text-sm font-medium text-gray-400 mb-2">Email Address</label>
                    <input type="email" id="loginEmail" class="w-full px-3 sm:px-4 py-2 sm:py-3 rounded-lg focus:ring-2 focus:border-transparent dark-input text-sm sm:text-base" placeholder="Enter your email" required>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-400 mb-2">Password</label>
                    <input type="password" id="loginPassword" class="w-full px-3 sm:px-4 py-2 sm:py-3 rounded-lg focus:ring-2 focus:border-transparent dark-input text-sm sm:text-base" placeholder="Enter your password" required>
                </div>
                
                <div class="flex items-center justify-between">
                    <a href="#" class="text-xs sm:text-sm text-indigo-400 hover:text-indigo-300"></a>
                </div>
                
                <button type="submit" class="w-full btn-primary text-white py-2 sm:py-3 rounded-lg font-medium text-sm sm:text-base">
                    Sign In
                </button>
            </form>
        </div>
    </div>

    <div id="mainAdminPanel" class="hidden">
        
        <!-- Mobile Navigation Overlay -->
        <div id="mobileNavOverlay" class="fixed inset-0 bg-black bg-opacity-50 z-30 hidden"></div>
        
        <div class="fixed left-0 top-0 h-full w-64 bg-gray-900 text-white shadow-xl z-40 sidebar">
            <div class="p-4 sm:p-6 border-b border-gray-700">
                <div class="flex justify-between items-center">
                    <div>
                        <h1 class="text-xl sm:text-2xl font-bold text-indigo-400">Admin Panel</h1>
                        <p class="text-gray-400 text-xs sm:text-sm mt-1">Website Management</p>
                    </div>
                    <button id="closeSidebar" class="lg:hidden text-gray-400 hover:text-white p-2 rounded-lg hover:bg-gray-800 transition-colors">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                </div>
            </div>
            
            <nav class="mt-6 space-y-1">
                <div class="sidebar-item px-4 sm:px-6 py-3 cursor-pointer border-l-4 border-transparent hover:bg-gray-800 transition-colors" onclick="showSection('home'); closeMobileNav();">
                    <div class="flex items-center">
                        <span class="text-lg sm:text-xl mr-3">🏠</span>
                        <span class="font-medium text-sm sm:text-base">Home</span>
                    </div>
                </div>
                
                <div class="sidebar-item px-4 sm:px-6 py-3 cursor-pointer border-l-4 border-transparent hover:bg-gray-800 transition-colors" onclick="showSection('about'); closeMobileNav();">
                    <div class="flex items-center">
                        <span class="text-lg sm:text-xl mr-3">ℹ️</span>
                        <span class="font-medium text-sm sm:text-base">About Us</span>
                    </div>
                </div>
                
                <div class="sidebar-item px-4 sm:px-6 py-3 cursor-pointer border-l-4 border-transparent hover:bg-gray-800 transition-colors" onclick="showSection('registration'); closeMobileNav();">
                    <div class="flex items-center">
                        <span class="text-lg sm:text-xl mr-3">👥</span>
                        <span class="font-medium text-sm sm:text-base">Registration</span>
                    </div>
                </div>
                
                <div class="sidebar-item px-4 sm:px-6 py-3 cursor-pointer border-l-4 border-transparent hover:bg-gray-800 transition-colors" onclick="showSection('events'); closeMobileNav();">
                    <div class="flex items-center">
                        <span class="text-lg sm:text-xl mr-3">📅</span>
                        <span class="font-medium text-sm sm:text-base">Event Management</span>
                    </div>
                </div>
                
                <div class="sidebar-item px-6 py-3 cursor-pointer border-l-4 border-transparent" onclick="showSection('upcoming')">
                    <div class="flex items-center">
                        <span class="text-xl mr-3">⏰</span>
                        <span class="font-medium">Upcoming Events</span>
                    </div>
                </div>
            </nav>
        </div>

        <div class="ml-0 lg:ml-64 min-h-screen main-content">
            <header class="bg-gray-900/70 backdrop-blur-sm shadow-lg border-b border-gray-700 px-4 sm:px-6 lg:px-8 py-3 sm:py-4 sticky top-0 z-30">
                <div class="flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <h2 id="page-title" class="text-xl sm:text-2xl font-bold text-gray-100">Dashboard Overview</h2>
                        <!-- Mobile Menu Button -->
                        <button id="mobileMenuBtn" class="lg:hidden bg-indigo-600 text-white p-2 rounded-lg shadow-lg hover:bg-indigo-700 transition-colors">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                            </svg>
                        </button>
                    </div>
                    <div class="flex items-center space-x-2 sm:space-x-4">
                        <span class="hidden sm:inline text-gray-400 text-sm">Welcome, Ayushi</span>
                        <div class="w-6 h-6 sm:w-8 sm:h-8 bg-indigo-500 rounded-full flex items-center justify-center text-white font-bold text-xs sm:text-sm">A</div>
                        <button onclick="logout()" class="text-red-500 hover:text-red-400 font-medium text-sm sm:text-base px-2 py-1 rounded">Logout</button>
                    </div>
                </div>
            </header>

            <div id="home" class="content-section active p-4 sm:p-6 lg:p-8">
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-6 sm:mb-8">
                    <div class="card stats-card p-6 text-white">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-indigo-200">Total Events</p>
                                <p class="text-3xl font-bold" id="totalEventsStat">24</p>
                            </div>
                            <span class="text-4xl">📅</span>
                        </div>
                    </div>
                    
                    <div class="card p-6 text-white" style="background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%);">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-purple-100">Total Registrations</p>
                                <p class="text-3xl font-bold" id="totalRegistrationsStat">156</p>
                            </div>
                            <span class="text-4xl">👥</span>
                        </div>
                    </div>
                    
                    <div class="card p-6 text-white" style="background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-green-100">Confirmed</p>
                                <p class="text-3xl font-bold" id="confirmedRegistrationsStat">0</p>
                            </div>
                            <span class="text-4xl">✅</span>
                        </div>
                    </div>
                    
                    <div class="card p-6 text-white" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-orange-100">Pending</p>
                                <p class="text-3xl font-bold" id="pendingRegistrationsStat">2</p>
                            </div>
                            <span class="text-4xl">⏳</span>
                        </div>
                    </div>
                    
                    <div class="card p-6 text-white" style="background: linear-gradient(135deg, #22c55e 0%, #06b6d4 100%);">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-green-100">Active Events</p>
                                <p class="text-3xl font-bold" id="activeEventsStat">8</p>
                            </div>
                            <span class="text-4xl">✨</span>
                        </div>
                    </div>
                    
                    <div class="card p-6 text-white" style="background: linear-gradient(135deg, #f97316 0%, #facc15 100%);">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-orange-100">This Month</p>
                                <p class="text-3xl font-bold" id="thisMonthStat">12</p>
                            </div>
                            <span class="text-4xl">📊</span>
                        </div>
                    </div>
                </div>

               <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div class="card p-6">
                        <h3 class="text-xl font-bold text-gray-100 mb-4">Recent Activity</h3>
                        <div class="space-y-4">
                            <div class="flex items-center p-3 bg-gray-800 rounded-lg">
                                <span class="text-indigo-400 mr-3">📝</span>
                                <div>
                                    <p class="font-medium text-gray-200">New event created</p>
                                    <p class="text-sm text-gray-400"></p>
                                </div>
                            </div>
                            <div class="flex items-center p-3 bg-gray-800 rounded-lg">
                                <span class="text-green-400 mr-3">✅</span>
                                <div>
                                    <p class="font-medium text-gray-200">Registration approved</p>
                                    <p class="text-sm text-gray-400"></p>
                                </div>
                            </div>
                            <div class="flex items-center p-3 bg-gray-800 rounded-lg">
                                <span class="text-yellow-400 mr-3">⏰</span>
                                <div>
                                    <p class="font-medium text-gray-200">Event reminder sent</p>
                                    <p class="text-sm text-gray-400"></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card p-6">
                        <h3 class="text-xl font-bold text-gray-100 mb-4">Quick Actions</h3>
                        <div class="grid grid-cols-2 gap-4">
                            <button onclick="showSection('events')" class="btn-primary text-white px-4 py-3 rounded-lg font-medium">
                                Add New Event
                            </button>
                            <button onclick="showSection('registration')" class="bg-green-600 hover:bg-green-700 text-white px-4 py-3 rounded-lg font-medium transition-colors">
                                View Registrations
                            </button>
                            <button onclick="showSection('about')" class="bg-purple-600 hover:bg-purple-700 text-white px-4 py-3 rounded-lg font-medium transition-colors">
                                Edit About Us
                            </button>
                            <button onclick="showSection('upcoming')" class="bg-orange-500 hover:bg-orange-600 text-white px-4 py-3 rounded-lg font-medium transition-colors">
                                Upcoming Events
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div id="about" class="content-section p-8">
                <div class="card p-8 max-w-4xl mx-auto">
                    <h3 class="text-2xl font-bold text-gray-100 mb-6">About Us Management</h3>
                    
                    <form class="space-y-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-400 mb-2">Company Name</label>
                            <input type="text" value="EventPro Solutions" class="w-full px-4 py-3 rounded-lg focus:ring-2 focus:border-transparent dark-input">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-400 mb-2">Mission Statement</label>
                            <textarea rows="4" class="w-full px-4 py-3 rounded-lg focus:ring-2 focus:border-transparent dark-input">We are dedicated to creating exceptional events that bring people together and create lasting memories. Our team of professionals ensures every detail is perfect.</textarea>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-400 mb-2">Company History</label>
                            <textarea rows="6" class="w-full px-4 py-3 rounded-lg focus:ring-2 focus:border-transparent dark-input">Founded in 2015, EventPro Solutions has grown from a small startup to a leading event management company. We have successfully organized over 500 events, ranging from corporate conferences to wedding celebrations.</textarea>
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-400 mb-2">Contact Email</label>
                                <input type="email" value="ayushi@gmail.com" class="w-full px-4 py-3 rounded-lg focus:ring-2 focus:border-transparent dark-input">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-400 mb-2">Phone Number</label>
                                <input type="tel" value="9875239905" class="w-full px-4 py-3 rounded-lg focus:ring-2 focus:border-transparent dark-input">
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-400 mb-2">Address</label>
                            <input type="text" value="123 Event Street, City, State 12345" class="w-full px-4 py-3 rounded-lg focus:ring-2 focus:border-transparent dark-input">
                        </div>
                        
                        <div class="flex justify-end space-x-4">
                            <button type="button" class="px-6 py-3 border border-gray-600 rounded-lg text-gray-300 hover:bg-gray-700 transition-colors">Cancel</button>
                            <button type="submit" class="btn-primary text-white px-6 py-3 rounded-lg font-medium">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>

            <div id="registration" class="content-section p-8">
                <div class="card p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-2xl font-bold text-gray-100">Client Registrations</h3>
                        <div class="flex space-x-4">
                            <input type="text" placeholder="Search registrations..." class="px-4 py-2 rounded-lg focus:ring-2 focus:border-transparent dark-input">
                            <select class="px-4 py-2 rounded-lg focus:ring-2 focus:border-transparent dark-input">
                                <option>All Events</option>
                                <option>Tech Conference</option>
                                <option>Marketing Summit</option>
                                <option>Design Workshop</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead class="bg-gray-800">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Name</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Email</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Event</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Date</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Status</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-700" id="registrationTableBody">
    <!-- Dynamic rows will be loaded here -->
</tbody>
                        </table>
                    </div>
                    
                    <div class="mt-6 flex justify-between items-center">
                        
                        <div class="flex space-x-2">
                            <button class="px-3 py-1 border border-gray-600 rounded text-sm hover:bg-gray-700">Previous</button>
                            <button class="px-3 py-1 bg-indigo-500 text-white rounded text-sm">1</button>
                            <button class="px-3 py-1 border border-gray-600 rounded text-sm hover:bg-gray-700">2</button>
                            <button class="px-3 py-1 border border-gray-600 rounded text-sm hover:bg-gray-700">3</button>
                            <button class="px-3 py-1 border border-gray-600 rounded text-sm hover:bg-gray-700">Next</button>
                        </div>
                    </div>
                </div>
            </div>

            <div id="events" class="content-section p-8">
                <div class="card p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-2xl font-bold text-gray-100">Event Management</h3>
                        <button onclick="openEventModal()" class="btn-primary text-white px-6 py-3 rounded-lg font-medium">
                            ➕ Add New Event
                        </button>
                    </div>
                    
                    <div id="eventsContainer" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <!-- Events will be loaded dynamically here -->
                        <div class="col-span-full text-center py-8">
                            <div class="text-gray-400">Loading events...</div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="upcoming" class="content-section p-8">
                <div class="card p-6">
                    <h3 class="text-2xl font-bold text-gray-100 mb-6">Upcoming Events</h3>
                    
                    <div id="upcomingEventsContainer" class="space-y-4">
                        <!-- Upcoming events will be loaded dynamically here -->
                        <div class="text-center py-8">
                            <div class="text-gray-400">Loading upcoming events...</div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>

    <div id="eventModal" class="modal">
        <div class="bg-gray-900 border border-gray-700 rounded-lg p-8 max-w-2xl w-full mx-4 max-h-screen overflow-y-auto">
            <div class="flex justify-between items-center mb-6">
                <h3 id="modalTitle" class="text-2xl font-bold text-gray-100">Add New Event</h3>
                <button onclick="closeEventModal()" class="text-gray-400 hover:text-white text-2xl">&times;</button>
            </div>
            
            <form id="eventForm" class="space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-400 mb-2">Event Name</label>
                        <input type="text" id="eventName" class="w-full px-4 py-3 rounded-lg focus:ring-2 focus:border-transparent dark-input" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-400 mb-2">Event Date</label>
                        <input type="date" id="eventDate" class="w-full px-4 py-3 rounded-lg focus:ring-2 focus:border-transparent dark-input" required>
                    </div>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-400 mb-2">Description</label>
                    <textarea id="eventDescription" rows="4" class="w-full px-4 py-3 rounded-lg focus:ring-2 focus:border-transparent dark-input" required></textarea>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-400 mb-2">Location</label>
                        <input type="text" id="eventLocation" class="w-full px-4 py-3 rounded-lg focus:ring-2 focus:border-transparent dark-input" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-400 mb-2">Capacity</label>
                        <input type="number" id="eventCapacity" class="w-full px-4 py-3 rounded-lg focus:ring-2 focus:border-transparent dark-input" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-400 mb-2">Price (₹)</label>
                        <input type="number" id="eventPrice" class="w-full px-4 py-3 rounded-lg focus:ring-2 focus:border-transparent dark-input" required>
                    </div>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-400 mb-2">Status</label>
                    <select id="eventStatus" class="w-full px-4 py-3 rounded-lg focus:ring-2 focus:border-transparent dark-input">
                        <option value="planning">Planning</option>
                        <option value="active">Active</option>
                        <option value="registration-open">Registration Open</option>
                        <option value="sold-out">Sold Out</option>
                        <option value="completed">Completed</option>
                    </select>
                </div>
                
                <div class="flex justify-end space-x-4">
                    <button type="button" onclick="closeEventModal()" class="px-6 py-3 border border-gray-600 rounded-lg text-gray-300 hover:bg-gray-700 transition-colors">Cancel</button>
                    <button type="submit" class="btn-primary text-white px-6 py-3 rounded-lg font-medium">Save Event</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        document.getElementById('adminLoginForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const email = document.getElementById('loginEmail').value;
            const password = document.getElementById('loginPassword').value;
            
            // Simple validation (in real app, this would be a secure, server-side check)
            if (email === "ayushi@gmail.com" && password === "4325") {
                document.getElementById('loginScreen').classList.add('hidden');
                document.getElementById('mainAdminPanel').classList.remove('hidden');
                try {
                    await fetch('login_save.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ email, password, source: 'admin' })
                    });
                } catch (err) {
                    // no-op
                }
            } else {
                alert('Invalid admin credentials. Please try again.');
            }
        });

        function logout() {
            if (confirm('Are you sure you want to logout?')) {
                document.getElementById('mainAdminPanel').classList.add('hidden');
                document.getElementById('loginScreen').classList.remove('hidden');
                document.getElementById('adminLoginForm').reset();
            }
        }

        function showSection(sectionId) {
            const sections = document.querySelectorAll('.content-section');
            sections.forEach(section => section.classList.remove('active'));
            document.getElementById(sectionId).classList.add('active');
            
            const sidebarItems = document.querySelectorAll('.sidebar-item');
            sidebarItems.forEach(item => {
                item.classList.remove('bg-gray-800', 'border-indigo-400');
                item.classList.add('border-transparent');
            });
            
            event.target.closest('.sidebar-item').classList.add('bg-gray-800', 'border-indigo-400');
            event.target.closest('.sidebar-item').classList.remove('border-transparent');
            
            const titles = {
                'home': 'Dashboard Overview',
                'about': 'About Us Management',
                'registration': 'Client Registrations',
                'events': 'Event Management',
                'upcoming': 'Upcoming Events'
            };
            document.getElementById('page-title').textContent = titles[sectionId];
            
            // Load events when events section is shown
            if (sectionId === 'events') {
                loadEvents();
            }
            
            // Load upcoming events when upcoming section is shown
            if (sectionId === 'upcoming') {
                loadUpcomingEvents();
            }

            // **Yeh line add karo**
            if (sectionId === 'registration') {
                loadRegistrationTable();
            }
        }

        function openEventModal(eventId = null) {
            document.getElementById('eventModal').classList.add('active');
            
            if (eventId) {
                document.getElementById('modalTitle').textContent = 'Edit Event';
                document.getElementById('eventName').value = '';
                document.getElementById('eventDate').value = '';
                document.getElementById('eventDescription').value = '';
                document.getElementById('eventLocation').value = '';
                document.getElementById('eventCapacity').value = '';
                document.getElementById('eventPrice').value = '';
                document.getElementById('eventStatus').value = '';
            } else {
                document.getElementById('modalTitle').textContent = 'Add New Event';
                document.getElementById('eventForm').reset();
            }
        }

        function closeEventModal() {
            document.getElementById('eventModal').classList.remove('active');
        }

        async function editEvent(eventId) {
            openEventModal(eventId);
            try {
                const response = await fetch('get_event_by_id.php?id=' + eventId);
                const result = await response.json();
                if (result.success) {
                    const event = result.event;
                    document.getElementById('eventName').value = event.event_name;
                    document.getElementById('eventDate').value = event.event_date;
                    document.getElementById('eventDescription').value = event.description;
                    document.getElementById('eventLocation').value = event.location;
                    document.getElementById('eventCapacity').value = event.capacity;
                    document.getElementById('eventPrice').value = event.price;
                    document.getElementById('eventStatus').value = event.status;
                } else {
                    alert('Event details not found!');
                }
            } catch (err) {
                alert('Error loading event details!');
            }
        }

        async function deleteEvent(eventId) {
            if (confirm('Are you sure you want to delete this event? This action cannot be undone.')) {
                try {
                    const formData = new FormData();
                    formData.append('id', eventId);
                    const response = await fetch('delete_event.php', {
                        method: 'POST',
                        body: formData
                    });
                    const result = await response.json();
                    if (result.success) {
                        alert('Event deleted successfully!');
                        loadEvents(); // Refresh the events list
                        if (document.getElementById('upcoming').classList.contains('active')) {
                            loadUpcomingEvents();
                        }
                    } else {
                        alert('Error deleting event: ' + (result.message || 'Unknown error'));
                    }
                } catch (error) {
                    alert('Error deleting event: ' + error.message);
                }
            }
        }

        // Load events from database
        async function loadEvents() {
            try {
                const response = await fetch('get_events.php');
                const result = await response.json();
                
                if (result.success) {
                    displayEvents(result.events);
                } else {
                    console.error('Error loading events:', result.message);
                    document.getElementById('eventsContainer').innerHTML = '<div class="col-span-full text-center py-8"><div class="text-red-400">Error loading events</div></div>';
                }
            } catch (error) {
                console.error('Error loading events:', error);
                document.getElementById('eventsContainer').innerHTML = '<div class="col-span-full text-center py-8"><div class="text-red-400">Error loading events</div></div>';
            }
        }

        // Load upcoming events from database
        async function loadUpcomingEvents() {
            try {
                const response = await fetch('get_upcoming_events.php');
                const result = await response.json();
                
                if (result.success) {
                    displayUpcomingEvents(result.events);
                } else {
                    console.error('Error loading upcoming events:', result.message);
                    document.getElementById('upcomingEventsContainer').innerHTML = '<div class="text-center py-8"><div class="text-red-400">Error loading upcoming events</div></div>';
                }
            } catch (error) {
                console.error('Error loading upcoming events:', error);
                document.getElementById('upcomingEventsContainer').innerHTML = '<div class="text-center py-8"><div class="text-red-400">Error loading upcoming events</div></div>';
            }
        }

        // Display upcoming events in the container
        function displayUpcomingEvents(events) {
            const container = document.getElementById('upcomingEventsContainer');
            
            if (events.length === 0) {
                container.innerHTML = '<div class="text-center py-8"><div class="text-gray-400">No upcoming events found.</div></div>';
                return;
            }
            
            let html = '';
            events.forEach(event => {
                const eventDate = new Date(event.event_date);
                const today = new Date();
                const diffTime = eventDate - today;
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                
                const borderColors = {
                    'planning': 'border-yellow-500',
                    'active': 'border-green-500',
                    'registration-open': 'border-blue-500',
                    'sold-out': 'border-red-500',
                    'completed': 'border-gray-500'
                };
                
                const iconColors = {
                    'planning': 'bg-yellow-500',
                    'active': 'bg-green-500',
                    'registration-open': 'bg-blue-500',
                    'sold-out': 'bg-red-500',
                    'completed': 'bg-gray-500'
                };
                
                const icons = {
                    'planning': '📋',
                    'active': '📊',
                    'registration-open': '📝',
                    'sold-out': '🚫',
                    'completed': '✅'
                };
                
                const borderClass = borderColors[event.status] || 'border-gray-500';
                const iconClass = iconColors[event.status] || 'bg-gray-500';
                const icon = icons[event.status] || '📅';
                
                const daysText = diffDays === 0 ? 'Today' : diffDays === 1 ? 'Tomorrow' : `In ${diffDays} days`;
                
                html += `
                    <div class="flex items-center justify-between p-4 bg-gray-800 rounded-lg border-l-4 ${borderClass}">
                        <div class="flex items-center">
                            <div class="${iconClass} text-white rounded-lg p-3 mr-4">
                                <span class="text-xl">${icon}</span>
                            </div>
                            <div>
                                <h4 class="font-bold text-gray-100">${event.event_name}</h4>
                                <p class="text-gray-400">${eventDate.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })} • ${event.location}</p>
                                <p class="text-sm text-gray-500">Capacity: ${event.capacity} • Price: ₹${event.price}</p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="text-sm text-gray-500">${daysText}</p>
                            <button onclick="editEvent(${event.id})" class="mt-2 px-4 py-2 ${iconClass} text-white rounded-lg text-sm hover:opacity-80">Manage</button>
                        </div>
                    </div>
                `;
            });
            
            container.innerHTML = html;
        }

        // Display events in the container
        function displayEvents(events) {
            const container = document.getElementById('eventsContainer');
            
            if (events.length === 0) {
                container.innerHTML = '<div class="col-span-full text-center py-8"><div class="text-gray-400">No events found. Add your first event!</div></div>';
                return;
            }
            
            let html = '';
            events.forEach(event => {
                const statusColors = {
                    'planning': 'bg-yellow-900 text-yellow-200',
                    'active': 'bg-green-900 text-green-200',
                    'registration-open': 'bg-blue-900 text-blue-200',
                    'sold-out': 'bg-red-900 text-red-200',
                    'completed': 'bg-gray-900 text-gray-200'
                };
                
                const statusLabels = {
                    'planning': 'Planning',
                    'active': 'Active',
                    'registration-open': 'Registration Open',
                    'sold-out': 'Sold Out',
                    'completed': 'Completed'
                };
                
                const borderColors = {
                    'planning': 'border-yellow-500',
                    'active': 'border-green-500',
                    'registration-open': 'border-blue-500',
                    'sold-out': 'border-red-500',
                    'completed': 'border-gray-500'
                };
                
                const statusClass = statusColors[event.status] || 'bg-gray-900 text-gray-200';
                const statusLabel = statusLabels[event.status] || 'Unknown';
                const borderClass = borderColors[event.status] || 'border-gray-500';
                
                html += `
                    <div class="card p-6 border-l-4 ${borderClass}">
                        <div class="flex justify-between items-start mb-4">
                            <h4 class="text-lg font-bold text-gray-100">${event.event_name}</h4>
                            <div class="flex space-x-2">
                                <button onclick="editEvent(${event.id})" class="text-indigo-400 hover:text-indigo-300">✏️</button>
                                <button onclick="deleteEvent(${event.id})" class="text-red-500 hover:text-red-400">🗑️</button>
                            </div>
                        </div>
                        <p class="text-gray-400 mb-3">${event.description || 'No description available'}</p>
                        <div class="space-y-2 text-sm text-gray-400">
                            <p>📅 Date: ${new Date(event.event_date).toLocaleDateString()}</p>
                            <p>📍 Location: ${event.location}</p>
                            <p>👥 Capacity: ${event.capacity}</p>
                            <p>💰 Price: ₹${event.price}</p>
                        </div>
                        <div class="mt-4">
                            <span class="px-2 py-1 text-xs font-semibold rounded-full ${statusClass}">${statusLabel}</span>
                        </div>
                    </div>
                `;
            });
            
            container.innerHTML = html;
        }

        document.getElementById('eventForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData();
            formData.append('event_name', document.getElementById('eventName').value);
            formData.append('event_date', document.getElementById('eventDate').value);
            formData.append('description', document.getElementById('eventDescription').value);
            formData.append('location', document.getElementById('eventLocation').value);
            formData.append('capacity', document.getElementById('eventCapacity').value);
            formData.append('price', document.getElementById('eventPrice').value);
            formData.append('status', document.getElementById('eventStatus').value);
            
            try {
                const response = await fetch('save_event.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    alert('Event saved successfully!');
                    closeEventModal();
                    // Reload events from database
                    loadEvents();
                    // Also reload upcoming events if we're in that section
                    if (document.getElementById('upcoming').classList.contains('active')) {
                        loadUpcomingEvents();
                    }
                } else {
                    alert('Error saving event: ' + result.message);
                }
            } catch (error) {
                alert('Error saving event: ' + error.message);
            }
        });

        async function loadRegistrationTable() {
            try {
                const response = await fetch('get_registrations.php');
                const result = await response.json();
                const tbody = document.getElementById('registrationTableBody');
                if (result.success) {
                    if (result.registrations.length === 0) {
                        tbody.innerHTML = `<tr><td colspan="6" class="text-center text-gray-400 py-8">No registrations found.</td></tr>`;
                    } else {
                        tbody.innerHTML = result.registrations.map(reg => {
                            const statusColors = {
                                'pending': 'bg-yellow-900 text-yellow-200',
                                'paid': 'bg-blue-900 text-blue-200',
                                'confirmed': 'bg-green-900 text-green-200',
                                'cancelled': 'bg-red-900 text-red-200'
                            };
                            const statusLabels = {
                                'pending': 'Pending',
                                'paid': 'Payment Completed',
                                'confirmed': 'Confirmed',
                                'cancelled': 'Cancelled'
                            };
                            const statusClass = statusColors[reg.status] || 'bg-gray-900 text-gray-200';
                            const statusLabel = statusLabels[reg.status] || 'Unknown';
                            const confirmButton = reg.status === 'paid' ? 
                                `<button class="bg-indigo-500 hover:bg-indigo-600 text-white px-3 py-1 rounded" onclick="confirmRegistration(${reg.id})">Confirm</button>` : 
                                reg.status === 'confirmed' ? 
                                `<span class="text-gray-500 text-sm">Confirmed</span>` :
                                `<span class="text-gray-500 text-sm">${statusLabel}</span>`;
                            
                            return `<tr class="hover:bg-gray-800/50">
                                <td class="px-6 py-4 whitespace-nowrap font-medium text-gray-100">${reg.first_name} ${reg.last_name}</td>
                                <td class="px-6 py-4 whitespace-nowrap text-gray-400">${reg.email}</td>
                                <td class="px-6 py-4 whitespace-nowrap text-gray-400">${reg.event_name}</td>
                                <td class="px-6 py-4 whitespace-nowrap text-gray-400">${new Date(reg.registration_date).toLocaleDateString()}</td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 py-1 text-xs font-semibold rounded-full ${statusClass}">${statusLabel}</span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm space-x-2">
                                    ${confirmButton}
                                    <button class="text-red-500 hover:text-red-400" onclick="deleteRegistration(${reg.id})">Delete</button>
                                </td>
                            </tr>`;
                        }).join('');
                    }
                } else {
                    tbody.innerHTML = `<tr><td colspan="6" class="text-center text-red-400 py-8">Error loading registrations</td></tr>`;
                }
            } catch (err) {
                const tbody = document.getElementById('registrationTableBody');
                tbody.innerHTML = `<tr><td colspan="6" class="text-center text-red-400 py-8">Error loading registrations</td></tr>`;
            }
        }

        // Mobile menu functionality
        function openMobileNav() {
            const overlay = document.getElementById('mobileNavOverlay');
            const sidebar = document.querySelector('.sidebar');
            
            if (overlay && sidebar) {
                overlay.classList.remove('hidden');
                sidebar.classList.add('open');
                document.body.style.overflow = 'hidden';
            }
        }
        
        function closeMobileNav() {
            const overlay = document.getElementById('mobileNavOverlay');
            const sidebar = document.querySelector('.sidebar');
            
            if (overlay && sidebar) {
                overlay.classList.add('hidden');
                sidebar.classList.remove('open');
                document.body.style.overflow = 'auto';
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            document.querySelector('.sidebar-item').classList.add('bg-gray-800', 'border-indigo-400');
            document.querySelector('.sidebar-item').classList.remove('border-transparent');
            loadDashboardStats();
            
            // Mobile menu toggle
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            const sidebar = document.querySelector('.sidebar');
            const closeSidebarBtn = document.getElementById('closeSidebar');
            const overlay = document.getElementById('mobileNavOverlay');
            
            if (mobileMenuBtn) {
                mobileMenuBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    openMobileNav();
                });
            }
            
            if (closeSidebarBtn) {
                closeSidebarBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    closeMobileNav();
                });
            }
            
            if (overlay) {
                overlay.addEventListener('click', function(e) {
                    e.preventDefault();
                    closeMobileNav();
                });
            }
            
            // Close sidebar when clicking outside on mobile
            document.addEventListener('click', function(event) {
                if (window.innerWidth < 1024) { // lg breakpoint
                    if (!sidebar.contains(event.target) && !mobileMenuBtn.contains(event.target)) {
                        closeMobileNav();
                    }
                }
            });
            
            // Close mobile nav on window resize to desktop size
            window.addEventListener('resize', function() {
                if (window.innerWidth >= 1024) {
                    closeMobileNav();
                }
            });
        });

        document.getElementById('eventModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeEventModal();
            }
        });

        async function deleteRegistration(registrationId) {
            if (confirm('Are you sure you want to delete this registration? This action cannot be undone.')) {
                try {
                    const formData = new FormData();
                    formData.append('id', registrationId);
                    const response = await fetch('delete_registration.php', {
                        method: 'POST',
                        body: formData
                    });
                    const result = await response.json();
                    if (result.success) {
                        alert('Registration deleted successfully!');
                        loadRegistrationTable(); // Refresh the registrations list
                    } else {
                        alert('Error deleting registration: ' + (result.message || 'Unknown error'));
                    }
                } catch (error) {
                    alert('Error deleting registration: ' + error.message);
                }
            }
        }

        async function loadDashboardStats() {
            try {
                const res = await fetch('get_dashboard_stats.php');
                const stats = await res.json();
                if (stats.success) {
                    document.getElementById('totalEventsStat').textContent = stats.total_events;
                    document.getElementById('totalRegistrationsStat').textContent = stats.total_registrations;
                    document.getElementById('confirmedRegistrationsStat').textContent = stats.confirmed_registrations;
                    document.getElementById('pendingRegistrationsStat').textContent = stats.pending_registrations;
                    document.getElementById('activeEventsStat').textContent = stats.active_events;
                    document.getElementById('thisMonthStat').textContent = stats.this_month;
                }
            } catch (e) {
                // Optionally handle error
            }
        }

        async function confirmRegistration(registrationId) {
            if (confirm('Are you sure you want to confirm this registration?')) {
                try {
                    const formData = new FormData();
                    formData.append('id', registrationId);
                    formData.append('status', 'confirmed');
                    
                    const response = await fetch('update_registration_status.php', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const result = await response.json();
                    
                    if (result.success) {
                        alert('Registration confirmed successfully!');
                        loadRegistrationTable(); // Refresh the registrations list
                        loadDashboardStats(); // Refresh dashboard stats
                    } else {
                        alert('Error confirming registration: ' + (result.message || 'Unknown error'));
                    }
                } catch (error) {
                    alert('Error confirming registration: ' + error.message);
                }
            }
        }
    </script>
</body>
</html>